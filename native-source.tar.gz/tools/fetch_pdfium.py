"""Fetch the exact PDFium binary used by the Linux portable build."""
from pathlib import Path
import hashlib
import io
import platform
import tarfile
import urllib.request

root = Path(__file__).resolve().parents[1]
if platform.machine().lower() not in ("x86_64", "amd64"):
    raise SystemExit("The Linux release currently targets x86_64.")
url = "https://github.com/bblanchon/pdfium-binaries/releases/download/chromium%2F7999/pdfium-linux-x64.tgz"
expected = "c3af580f9df0fef9545b44115bc5ea440f286956b5f231df69fb373b8efc4f69"
cache = root / "build/deps/pdfium-linux.tgz"
cache.parent.mkdir(parents=True, exist_ok=True)
data = cache.read_bytes() if cache.exists() else urllib.request.urlopen(url, timeout=90).read()
if hashlib.sha256(data).hexdigest() != expected:
    raise SystemExit("PDFium archive checksum mismatch.")
cache.write_bytes(data)
destination = root / "build/deps/pdfium-linux"
destination.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
    for member in archive.getmembers():
        target = (destination / member.name).resolve()
        inside = destination.resolve() in target.parents or (target == destination.resolve() and member.isdir())
        if not inside or member.issym() or member.islnk():
            raise SystemExit("Unexpected archive path or link.")
    archive.extractall(destination)
print(f"Verified PDFium SDK: {destination}")
