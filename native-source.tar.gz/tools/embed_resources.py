"""Build compressed, read-only resources; Python is not required at runtime."""
from pathlib import Path
import sys
import zlib

root = Path(__file__).resolve().parents[1]
licenses = (root / "LICENSE").read_text(encoding="utf-8")
for path in sorted((root / "third_party").rglob("*")):
    if path.is_file():
        raw = path.read_bytes()
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            text = raw.decode("cp1252")
        licenses += "\n\n----- " + path.name + " -----\n" + text
resources = {102: licenses, 103: (root / "GUIDE.txt").read_text(encoding="utf-8"),
             104: (root / "src/python_api.py").read_text(encoding="utf-8")}
out = ['#include "portable.h"', '#include <zlib.h>']
for key, value in resources.items():
    raw = value.encode("utf-8") + b"\0"
    data = zlib.compress(raw, 9)
    out.append(f"static const unsigned char resource_{key}[]={{" + ",".join(map(str, data)) + "};")
out.append("wchar_t *portable_text(int id) { const unsigned char *data;uLongf n;size_t size;switch(id) {")
for key, value in resources.items():
    out.append(f"case {key}: data=resource_{key};n={len(value.encode('utf-8'))+1};size=sizeof(resource_{key});break;")
out.append("default:return NULL;}char *utf=malloc(n);wchar_t *wide=malloc(n*sizeof(wchar_t));if(!utf || !wide || uncompress((Bytef *)utf,&n,data,size)!=Z_OK || !wide_from_utf8(utf,wide,n)) { free(wide);wide=NULL; }free(utf);return wide;}")
Path(sys.argv[1]).write_text("\n".join(out), encoding="utf-8")
