"""Bundle the native Linux app and shared libraries; no Python runtime is shipped."""
from pathlib import Path
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / (sys.argv[1] if len(sys.argv) > 1 else "build/linux")).resolve()
DIST = ROOT / "portable"
DIST.mkdir(exist_ok=True)
# Keep the host's libc/loader pair together. Other dependencies are replaceable
# shared libraries in the portable directory, including GTK and PDFium.
SYSTEM = re.compile(r"^(ld-linux.*|lib(c|m|pthread|dl|rt|resolv|util|anl)\.so(?:\..*)?)$")

def run(*args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)

def dependencies(path):
    result = run("ldd", str(path), capture_output=True, text=True).stdout
    if "not found" in result:
        raise RuntimeError(result)
    return [Path(m) for m in re.findall(r"=> (/[^\s]+)", result)]

with tempfile.TemporaryDirectory(prefix="lengto-package-", dir=ROOT / "build") as temp:
    app = Path(temp) / "lengto.AppDir"
    (app / "usr/bin").mkdir(parents=True)
    (app / "usr/lib").mkdir()
    notices = app / "usr/share/licenses"
    notices.mkdir(parents=True)
    exe = app / "usr/bin/lengto"
    shutil.copy2(BUILD / "lengto", exe)
    libraries = dependencies(BUILD / "lengto")
    # Clipboard PNG serialization uses the distribution's GdkPixbuf PNG loader.
    for directory in (Path("/usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0/2.10.0/loaders"),):
        for loader in directory.glob("libpixbufloader-png.so"):
            target = app / "usr/lib/gdk-pixbuf-loaders" / loader.name
            target.parent.mkdir(exist_ok=True)
            shutil.copy2(loader, target)
            libraries += dependencies(loader)
    copied = set()
    packages = set()
    for library in libraries:
        if SYSTEM.match(library.name) or library.name in copied:
            continue
        copied.add(library.name)
        shutil.copy2(library, app / "usr/lib" / library.name)
        lookup = subprocess.run(["dpkg-query", "-S", str(library)], capture_output=True, text=True)
        if lookup.returncode:
            lookup = subprocess.run(["dpkg-query", "-S", "*/" + library.name], capture_output=True, text=True)
        for line in lookup.stdout.splitlines():
            packages.add(line.split(": ", 1)[0].split(":", 1)[0])
    for file in [exe, *(app / "usr/lib").glob("*.so*")]:
        run("strip", "--strip-unneeded", str(file))
    run("patchelf", "--set-rpath", "$ORIGIN/../lib", str(exe))
    provenance = []
    for package in sorted(packages):
        copyright_file = Path("/usr/share/doc") / package / "copyright"
        if copyright_file.exists():
            shutil.copy2(copyright_file, notices / (package + ".txt"))
        meta = subprocess.run(["dpkg-query", "-W", "-f=${Package} ${Version} ${source:Package} ${source:Version}\n", package], capture_output=True, text=True)
        provenance.append(meta.stdout)
    (notices / "versions.txt").write_text("".join(provenance), encoding="utf-8")
    shutil.copy2(ROOT / "LICENSE", notices / "lengto.txt")
    shutil.copytree(ROOT / "third_party", notices / "pdfium")
    (notices / "README.txt").write_text(
        "The unmodified shared libraries in usr/lib are dynamically linked.\n"
        "Their licenses and exact distribution source package versions are included here.\n"
        "Corresponding sources: https://archive.ubuntu.com/ubuntu/pool/ (use the listed source package/version).\n"
        "GTK: https://www.gtk.org/ ; PDFium provenance is in pdfium/.\n"
        "Extract the AppImage or portable archive to inspect or replace these libraries.\n", encoding="utf-8")
    desktop = ROOT / "packaging/linux/io.github.IvanPanzera.lengto.desktop"
    shutil.copy2(desktop, app / desktop.name)
    shutil.copy2(ROOT / "src/assets/lengto-symbol.png", app / "lengto.png")
    (app / ".DirIcon").symlink_to("lengto.png")
    launcher = app / "AppRun"
    launcher.write_text('''#!/bin/sh
set -eu
APPDIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export LENGTO_ORIGINAL_LD_LIBRARY_PATH="${LD_LIBRARY_PATH-}"
export LD_LIBRARY_PATH="$APPDIR/usr/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
if [ -d "$APPDIR/usr/lib/gdk-pixbuf-loaders" ]; then
    # The cache contains relocatable paths generated only for this invocation.
    # The PNG loader is not needed when GdkPixbuf was built with PNG included.
    export GDK_PIXBUF_MODULEDIR="$APPDIR/usr/lib/gdk-pixbuf-loaders"
fi
exec "$APPDIR/usr/bin/lengto" "$@"
''', encoding="utf-8")
    launcher.chmod(0o755)
    readme = """lengto — Linux portable

Extract this directory, then double-click AppRun (or run ./AppRun).
Keep the directory together; no installation or administrator access is needed.
This package includes GTK and the PDF/image libraries, but uses the host's libc,
display server and fonts. Release packages are built on Ubuntu 22.04 x86_64.
Python 3.8+ is optional and required only to run scripts, not to record them.

For the single-file AppImage: chmod +x lengto-linux-x86_64.AppImage, then open it.
If FUSE is unavailable, use --appimage-extract-and-run, or use this archive.
Guide and component licenses are available inside the application.
https://github.com/IvanPanzera/lengto
"""
    (app / "README.txt").write_text(readme, encoding="utf-8")
    archive = DIST / "lengto-linux-x86_64.tar.xz"
    with tarfile.open(archive, "w:xz", preset=9) as tar:
        tar.add(app, arcname="lengto")
    # Tooling is checksum-pinned; a changed continuous asset fails closed.
    tool = ROOT / "build/deps/appimagetool-x86_64.AppImage"
    expected = "a6d71e2b6cd66f8e8d16c37ad164658985e0cf5fcaa950c90a482890cb9d13e0"
    if not tool.exists():
        tool.write_bytes(urllib.request.urlopen("https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-x86_64.AppImage", timeout=90).read())
    if hashlib.sha256(tool.read_bytes()).hexdigest() != expected:
        raise RuntimeError("AppImage packaging tool checksum mismatch. Review and update the pinned release.")
    tool.chmod(0o755)
    runtime = ROOT / "build/deps/appimage-runtime-x86_64"
    runtime_hash = "156f4bdbde9c52d01814600013e0a273f0118dc2de98975f3c8c63427ec79074"
    if not runtime.exists():
        runtime.write_bytes(urllib.request.urlopen("https://github.com/AppImage/type2-runtime/releases/download/continuous/runtime-x86_64", timeout=90).read())
    if hashlib.sha256(runtime.read_bytes()).hexdigest() != runtime_hash:
        raise RuntimeError("AppImage runtime checksum mismatch.")
    env = dict(os.environ, APPIMAGE_EXTRACT_AND_RUN="1", ARCH="x86_64")
    run(str(tool), "--comp", "zstd", "--runtime-file", str(runtime), str(app), str(DIST / "lengto-linux-x86_64.AppImage"), env=env)
    for path in (archive, DIST / "lengto-linux-x86_64.AppImage"):
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        (Path(str(path) + ".sha256")).write_text(digest + "  " + path.name + "\n", encoding="ascii")
        print(f"{path.name}: {path.stat().st_size:,} bytes; SHA-256 {digest}")
