#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$root"
build=${1:-build/macos}
app="$build/lengto.app"
if command -v cmake >/dev/null 2>&1; then
    cmake -S . -B "$build" -DCMAKE_BUILD_TYPE=MinSizeRel '-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64' -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0
    cmake --build "$build" --parallel
    ctest --test-dir "$build" --output-on-failure
else
    # Xcode Command Line Tools include clang and Python. Homebrew is optional.
    xcrun --find clang >/dev/null
    mkdir -p "$app/Contents/MacOS"
    python3 tools/embed_resources.py "$build/resources.c"
    xcrun clang -arch arm64 -arch x86_64 -std=c17 -Os -Wall -Wextra \
        -Wno-misleading-indentation -mmacosx-version-min=11.0 -Isrc \
        src/platform.c src/model.c src/script_json.c src/automation.c src/recorder.c \
        src/unix/document.c src/unix/render.c src/unix/app.c src/unix/script.c \
        src/unix/diagnostics.c src/unix/mac_native.m "$build/resources.c" \
        -framework AppKit -framework CoreGraphics -framework ImageIO -framework CoreText \
        -lz -o "$app/Contents/MacOS/lengto"
    cp packaging/macos/Info.plist "$app/Contents/Info.plist"
    LENGTO_TEST_EXE="$root/$app/Contents/MacOS/lengto" python3 tests/test_scripts.py
fi
mkdir -p "$app/Contents/Resources" portable
icons="$build/lengto.iconset"
mkdir -p "$icons"
for size in 16 32 128 256 512; do
    sips -z "$size" "$size" src/assets/lengto-symbol.png --out "$icons/icon_${size}x${size}.png" >/dev/null
    twice=$((size * 2))
    sips -z "$twice" "$twice" src/assets/lengto-symbol.png --out "$icons/icon_${size}x${size}@2x.png" >/dev/null
done
iconutil -c icns "$icons" -o "$app/Contents/Resources/lengto.icns"
# System frameworks only: the executable must never depend on Homebrew paths.
lipo "$app/Contents/MacOS/lengto" -verify_arch arm64 x86_64
for arch in arm64 x86_64; do
    if otool -arch "$arch" -L "$app/Contents/MacOS/lengto" | tail -n +2 | grep -vE '^\s+(/System/Library/|/usr/lib/)' | grep -q .; then
        echo "Unexpected external runtime dependency in $arch." >&2
        exit 1
    fi
done
strip -x "$app/Contents/MacOS/lengto"
cp LICENSE "$app/Contents/Resources/LICENSE.txt"
# An ad-hoc signature supports native Apple Silicon execution. Distribution
# signing/notarization requires the maintainer's Apple Developer ID credentials.
codesign --force --deep --sign - "$app"
codesign --verify --deep --strict "$app"
ditto -c -k --sequesterRsrc --keepParent "$app" portable/lengto-macos-universal.zip
shasum -a 256 portable/lengto-macos-universal.zip
