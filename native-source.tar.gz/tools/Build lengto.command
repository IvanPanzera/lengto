#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$root"
if ! xcode-select -p >/dev/null 2>&1; then
    echo 'Install Apple Command Line Tools first: xcode-select --install'
    exit 1
fi
mkdir -p build
if sh tools/package_macos.sh >build/macos-build.log 2>&1; then
    cat build/macos-build.log
    echo 'Ready: portable/lengto-macos-universal.zip'
    open "$root/portable"
else
    cat build/macos-build.log
    echo 'Build or verification failed. Share build/macos-build.log to diagnose it.'
    exit 1
fi
