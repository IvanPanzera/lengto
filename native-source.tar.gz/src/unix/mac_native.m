#import <AppKit/AppKit.h>
#import <ImageIO/ImageIO.h>
#import <CoreText/CoreText.h>
#include "native.h"
#include <locale.h>
#include <math.h>

static NSString *nswide(const wchar_t *s) { char *utf=utf8_from_wide(s);NSString *text=utf?[NSString stringWithUTF8String:utf]:@"";free(utf);return text; }
static CGContextRef raster_context(HBITMAP r) { CGColorSpaceRef cs=CGColorSpaceCreateDeviceRGB();CGContextRef cr=CGBitmapContextCreate(r->pixels,r->width,r->height,8,r->width*4,cs,kCGImageAlphaPremultipliedFirst|kCGBitmapByteOrder32Little);CGColorSpaceRelease(cs);return cr; }
static CGImageRef raster_image(HBITMAP r) { CGContextRef cr=raster_context(r);CGImageRef im=cr?CGBitmapContextCreateImage(cr):NULL;if(cr) CGContextRelease(cr);return im; }
static HBITMAP decode(CGImageRef image) {
    if(!image) return NULL;HBITMAP r=raster_new((int)CGImageGetWidth(image),(int)CGImageGetHeight(image));if(!r) return NULL;CGContextRef cr=raster_context(r);if(!cr) { bitmap_free(r);return NULL; }
    CGContextSetRGBFillColor(cr,1,1,1,1);CGContextFillRect(cr,CGRectMake(0,0,r->width,r->height));CGContextDrawImage(cr,CGRectMake(0,0,r->width,r->height),image);CGContextRelease(cr);return r;
}
typedef struct { CGImageSourceRef image;CGPDFDocumentRef pdf; } Source;
static NSAutoreleasePool *nativePool;
int imaging_init(void) { nativePool=[[NSAutoreleasePool alloc] init];return 1; }
void imaging_shutdown(void) { [nativePool drain];nativePool=nil; }
void *source_open(const char *path,int *pages,int *pdf) {
    Source *s=calloc(1,sizeof(*s));if(!s) return NULL;NSURL *url=[NSURL fileURLWithPath:[NSString stringWithUTF8String:path]];
    unsigned char signature[4]={0};FILE *file=fopen(path,"rb");if(file) { fread(signature,1,4,file);fclose(file); }
    if(!memcmp(signature,"%PDF",4)) s->pdf=CGPDFDocumentCreateWithURL((CFURLRef)url);if(s->pdf) { *pdf=1;*pages=(int)CGPDFDocumentGetNumberOfPages(s->pdf); }
    else { s->image=CGImageSourceCreateWithURL((CFURLRef)url,NULL);if(!s->image) { free(s);return NULL; }CFStringRef type=CGImageSourceGetType(s->image);if(!CFEqual(type,CFSTR("public.png")) && !CFEqual(type,CFSTR("public.jpeg")) && !CFEqual(type,CFSTR("public.tiff"))) { source_close(s);return NULL; }*pdf=0;*pages=(int)CGImageSourceGetCount(s->image); }return s;
}
void source_close(void *source) { Source *s=source;if(!s) return;if(s->image) CFRelease(s->image);if(s->pdf) CGPDFDocumentRelease(s->pdf);free(s); }
HBITMAP source_page(void *source,int page) {
    Source *s=source;if(s->image) { CGImageRef im=CGImageSourceCreateImageAtIndex(s->image,page,NULL);HBITMAP r=decode(im);if(im) CGImageRelease(im);return r; }
    CGPDFPageRef p=CGPDFDocumentGetPage(s->pdf,page+1);if(!p) return NULL;CGRect box=CGPDFPageGetBoxRect(p,kCGPDFMediaBox);int rotation=CGPDFPageGetRotationAngle(p);double w=ceil(box.size.width*2),h=ceil(box.size.height*2);if(rotation%180) { double temp=w;w=h;h=temp; }if(w>100000000 || h>100000000) return NULL;HBITMAP r=raster_new((int)w,(int)h);if(!r) return NULL;CGContextRef cr=raster_context(r);if(!cr) { bitmap_free(r);return NULL; }
    CGContextSetRGBFillColor(cr,1,1,1,1);CGContextFillRect(cr,CGRectMake(0,0,w,h));CGContextConcatCTM(cr,CGPDFPageGetDrawingTransform(p,kCGPDFMediaBox,CGRectMake(0,0,w,h),0,true));CGContextDrawPDFPage(cr,p);CGContextRelease(cr);return r;
}
HBITMAP source_memory(const void *data,size_t size) { CFDataRef bytes=CFDataCreate(NULL,data,size);CGImageSourceRef src=CGImageSourceCreateWithData(bytes,NULL);CGImageRef im=src?CGImageSourceCreateImageAtIndex(src,0,NULL):NULL;HBITMAP r=decode(im);if(im) CGImageRelease(im);if(src) CFRelease(src);CFRelease(bytes);return r; }
unsigned char *raster_png(HBITMAP r,size_t *size) {
    CGImageRef im=raster_image(r);if(!im) return NULL;CFMutableDataRef bytes=CFDataCreateMutable(NULL,0);CGImageDestinationRef dest=CGImageDestinationCreateWithData(bytes,CFSTR("public.png"),1,NULL);unsigned char *out=NULL;
    if(dest) { CGImageDestinationAddImage(dest,im,NULL);if(CGImageDestinationFinalize(dest)) { *size=(size_t)CFDataGetLength(bytes);out=malloc(*size);if(out) memcpy(out,CFDataGetBytePtr(bytes),*size); }CFRelease(dest); }CFRelease(bytes);CGImageRelease(im);return out;
}
typedef struct { ExportFormat format;char *path;CGContextRef pdf;char **spool;int count,failed; } Writer;
void *writer_open(const char *path,ExportFormat format) {
    Writer *w=calloc(1,sizeof(*w));if(!w) return NULL;w->format=format;w->path=strdup(path);
    if(format==EXPORT_PDF) { NSURL *url=[NSURL fileURLWithPath:[NSString stringWithUTF8String:path]];w->pdf=CGPDFContextCreateWithURL((CFURLRef)url,NULL,NULL);if(!w->pdf) { free(w->path);free(w);return NULL; } }return w;
}
static int write_image(const char *path,HBITMAP r,CFStringRef type) {
    NSURL *url=[NSURL fileURLWithPath:[NSString stringWithUTF8String:path]];CGImageDestinationRef dest=CGImageDestinationCreateWithURL((CFURLRef)url,type,1,NULL);CGImageRef im=raster_image(r);int ok=0;
    if(dest && im) { NSDictionary *props=@{(NSString *)kCGImageDestinationLossyCompressionQuality:@0.95,(NSString *)kCGImagePropertyDPIWidth:@144,(NSString *)kCGImagePropertyDPIHeight:@144};CGImageDestinationAddImage(dest,im,(CFDictionaryRef)props);ok=CGImageDestinationFinalize(dest); }if(dest) CFRelease(dest);if(im) CGImageRelease(im);return ok;
}
int writer_page(void *writer,HBITMAP r,double width,double height) {
    Writer *w=writer;int ok=0;if(w->failed || (w->count && (w->format==EXPORT_PNG || w->format==EXPORT_JPEG))) return 0;
    if(w->format==EXPORT_PDF) { CGRect rect=CGRectMake(0,0,width,height);CFDataRef box=CFDataCreate(NULL,(const UInt8 *)&rect,sizeof(rect));const void *key=kCGPDFContextMediaBox,*value=box;CFDictionaryRef info=CFDictionaryCreate(NULL,&key,&value,1,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks);CGPDFContextBeginPage(w->pdf,info);CGImageRef image=raster_image(r);if(image) { CGContextDrawImage(w->pdf,rect,image);CGImageRelease(image);ok=1; }CGPDFContextEndPage(w->pdf);CFRelease(info);CFRelease(box); }
    else if(w->format==EXPORT_TIFF) {
        /* Spool pages to disk: ImageIO needs the final page count up front. */
        char **list=realloc(w->spool,(w->count+1)*sizeof(char *));if(!list) goto done;w->spool=list;char *temp=malloc(strlen(w->path)+20);if(!temp) goto done;sprintf(temp,"%s.page.XXXXXX",w->path);int fd=mkstemp(temp);if(fd<0) { free(temp);goto done; }close(fd);ok=write_image(temp,r,CFSTR("public.png"));if(ok) w->spool[w->count]=temp;else { unlink(temp);free(temp); }
    }else ok=write_image(w->path,r,w->format==EXPORT_JPEG?CFSTR("public.jpeg"):CFSTR("public.png"));
done:if(ok) w->count++;else w->failed=1;return ok;
}
int writer_close(void *writer) {
    Writer *w=writer;if(!w) return 0;int ok=!w->failed && w->count>0;
    if(w->pdf) { CGPDFContextClose(w->pdf);CGContextRelease(w->pdf); }
    if(w->format==EXPORT_TIFF && ok) {
        NSURL *url=[NSURL fileURLWithPath:[NSString stringWithUTF8String:w->path]];CGImageDestinationRef dest=CGImageDestinationCreateWithURL((CFURLRef)url,CFSTR("public.tiff"),w->count,NULL);if(!dest) ok=0;
        for(int i=0;i<w->count && ok;i++) { @autoreleasepool { NSURL *page=[NSURL fileURLWithPath:[NSString stringWithUTF8String:w->spool[i]]];CGImageSourceRef src=CGImageSourceCreateWithURL((CFURLRef)page,NULL);if(src) { NSDictionary *props=@{(NSString *)kCGImagePropertyTIFFDictionary:@{(NSString *)kCGImagePropertyTIFFCompression:@5}};CGImageDestinationAddImageFromSource(dest,src,0,(CFDictionaryRef)props);CFRelease(src); }else ok=0; } }
        if(dest) { if(ok) ok=CGImageDestinationFinalize(dest);CFRelease(dest); }
    }
    if(w->spool) { for(int i=0;i<w->count;i++) { unlink(w->spool[i]);free(w->spool[i]); }free(w->spool); }free(w->path);free(w);return ok;
}
void *paint_begin(HBITMAP r) { CGContextRef cr=raster_context(r);if(cr) { CGContextTranslateCTM(cr,0,r->height);CGContextScaleCTM(cr,1,-1); }return cr; }
void paint_end(void *cr) { CGContextFlush(cr);CGContextRelease(cr); }
static void color(CGContextRef cr,COLORREF c) { CGContextSetRGBFillColor(cr,(c&255)/255.,((c>>8)&255)/255.,((c>>16)&255)/255.,1);CGContextSetRGBStrokeColor(cr,(c&255)/255.,((c>>8)&255)/255.,((c>>16)&255)/255.,1); }
void paint_rect(void *cr,double x,double y,double w,double h,COLORREF c) { CGContextSaveGState(cr);color(cr,c);CGContextFillRect(cr,CGRectMake(x,y,w,h));CGContextRestoreGState(cr); }
void paint_image(void *cr,HBITMAP r,double x,double y,double w,double h,int nearest) { CGImageRef im=raster_image(r);if(!im) return;CGContextSaveGState(cr);CGContextSetInterpolationQuality(cr,nearest?kCGInterpolationNone:kCGInterpolationHigh);CGContextTranslateCTM(cr,x,y+h);CGContextScaleCTM(cr,1,-1);CGContextDrawImage(cr,CGRectMake(0,0,w,h),im);CGContextRestoreGState(cr);CGImageRelease(im); }
void paint_line(void *cr,double x,double y,double xx,double yy,COLORREF c,double width,int dashed) { CGContextSaveGState(cr);color(cr,c);CGContextSetLineWidth(cr,width);CGFloat dash[]={5,4};if(dashed) CGContextSetLineDash(cr,0,dash,2);CGContextMoveToPoint(cr,x,y);CGContextAddLineToPoint(cr,xx,yy);CGContextStrokePath(cr);CGContextRestoreGState(cr); }
static CTLineRef text_line(const wchar_t *text,double size,COLORREF c) { NSColor *color=[NSColor colorWithRed:(c&255)/255. green:((c>>8)&255)/255. blue:((c>>16)&255)/255. alpha:1];NSAttributedString *a=[[NSAttributedString alloc] initWithString:nswide(text) attributes:@{NSFontAttributeName:[NSFont systemFontOfSize:size],NSForegroundColorAttributeName:color}];CTLineRef line=CTLineCreateWithAttributedString((CFAttributedStringRef)a);[a release];return line; }
void paint_text(void *cr,double x,double y,const wchar_t *text,double size,COLORREF c) { CTLineRef line=text_line(text,size,c);CGContextSaveGState(cr);CGContextTranslateCTM(cr,x,y+size);CGContextScaleCTM(cr,1,-1);CGContextSetTextMatrix(cr,CGAffineTransformIdentity);CGContextSetTextPosition(cr,0,0);CTLineDraw(line,cr);CGContextRestoreGState(cr);CFRelease(line); }
double text_width(const wchar_t *text,double size) { CTLineRef line=text_line(text,size,0);double w=CTLineGetTypographicBounds(line,NULL,NULL,NULL);CFRelease(line);return w; }

@interface LengtoView : NSView @end
@interface LengtoDelegate : NSObject <NSApplicationDelegate,NSWindowDelegate,NSTextFieldDelegate>
- (void)command:(id)sender;
- (void)page:(id)sender;
- (void)tick:(NSTimer *)timer;
@end
static NSWindow *window;static LengtoView *canvas;static NSTextField *status,*pageEntry,*pageTotal;static NSButton *previous,*next;static NSMenuItem *items[32];static LengtoDelegate *delegate;static int updating;
@implementation LengtoView
- (BOOL)isFlipped { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }
- (void)drawRect:(NSRect)dirty { (void)dirty;app_resize((int)self.bounds.size.width,(int)self.bounds.size.height);app_draw([[NSGraphicsContext currentContext] CGContext]); }
- (void)mouseDown:(NSEvent *)e { [window makeFirstResponder:self];NSPoint p=[self convertPoint:e.locationInWindow fromView:nil];app.shift=(e.modifierFlags&NSEventModifierFlagShift)!=0;app_mouse(0,p.x,p.y); }
- (void)mouseDragged:(NSEvent *)e { NSPoint p=[self convertPoint:e.locationInWindow fromView:nil];app.shift=(e.modifierFlags&NSEventModifierFlagShift)!=0;app_mouse(1,p.x,p.y); }
- (void)mouseMoved:(NSEvent *)e { NSPoint p=[self convertPoint:e.locationInWindow fromView:nil];app.shift=(e.modifierFlags&NSEventModifierFlagShift)!=0;app_mouse(1,p.x,p.y); }
- (void)mouseUp:(NSEvent *)e { NSPoint p=[self convertPoint:e.locationInWindow fromView:nil];app.shift=(e.modifierFlags&NSEventModifierFlagShift)!=0;app_mouse(2,p.x,p.y); }
- (void)rightMouseUp:(NSEvent *)e { NSPoint p=[self convertPoint:e.locationInWindow fromView:nil];app_mouse(3,p.x,p.y); }
- (void)scrollWheel:(NSEvent *)e { NSPoint p=[self convertPoint:e.locationInWindow fromView:nil];app_zoom(e.hasPreciseScrollingDeltas?e.scrollingDeltaY/12:e.scrollingDeltaY,p.x,p.y); }
- (void)keyDown:(NSEvent *)e { if(e.keyCode==53) app_key(27);else if(e.keyCode==51 || e.keyCode==117) app_key(127);else if(e.keyCode==116) app_command(CMD_PREV);else if(e.keyCode==121) app_command(CMD_NEXT);else { NSString *s=e.charactersIgnoringModifiers.lowercaseString;if([s isEqualToString:@"c"]) app_command(CMD_CALIBRATE);else if([s isEqualToString:@"m"]) app_command(CMD_MEASURE);else if([s isEqualToString:@"f"]) app_command(CMD_FIT);else [super keyDown:e]; } }
- (NSDragOperation)draggingEntered:(id<NSDraggingInfo>)sender { (void)sender;return script_running()?NSDragOperationNone:NSDragOperationCopy; }
- (BOOL)performDragOperation:(id<NSDraggingInfo>)sender { NSArray *urls=[[sender draggingPasteboard] readObjectsForClasses:@[[NSURL class]] options:@{NSPasteboardURLReadingFileURLsOnlyKey:@YES}];if(!urls.count) return NO;wchar_t path[P2L_PATH];if(!wide_from_utf8([[[urls firstObject] path] UTF8String],path,P2L_PATH)) return NO;app_open(path);return YES; }
@end
@implementation LengtoDelegate
- (void)command:(id)sender { app_command((int)[sender tag]); }
- (void)page:(id)sender { (void)sender;if(updating) return;NSString *s=pageEntry.stringValue;NSScanner *scanner=[NSScanner scannerWithString:s];NSInteger n;if([scanner scanInteger:&n] && scanner.isAtEnd && app.document.pages) app_page((int)max(1,min(app.document.pages,n)));else ui_title(NULL,NULL,app.document.page+1,app.document.pages,app.recorder.active,script_running()); }
- (void)controlTextDidEndEditing:(NSNotification *)n { (void)n;[self page:pageEntry]; }
- (BOOL)control:(NSControl *)control textView:(NSTextView *)view doCommandBySelector:(SEL)command { (void)control;(void)view;if(command==@selector(cancelOperation:)) { ui_title(NULL,NULL,app.document.page+1,app.document.pages,app.recorder.active,script_running());[window makeFirstResponder:canvas];return YES; }return NO; }
- (void)tick:(NSTimer *)timer { (void)timer;app_tick(); }
- (BOOL)windowShouldClose:(NSWindow *)sender { (void)sender;if(!app_quit()) return NO;[NSApp stop:nil];return YES; }
- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender { (void)sender;if(!app_quit()) return NSTerminateCancel;[NSApp stop:nil];return NSTerminateCancel; }
- (BOOL)application:(NSApplication *)sender openFile:(NSString *)file { (void)sender;wchar_t path[P2L_PATH];if(!wide_from_utf8(file.UTF8String,path,P2L_PATH)) return NO;app_open(path);return YES; }
- (BOOL)validateMenuItem:(NSMenuItem *)item { return item.enabled; }
@end
void ui_refresh(void) { [canvas setNeedsDisplay:YES]; }
void ui_title(const char *title,const char *text,int page,int pages,int recording,int running) {
    if(!window) return;if(title) window.title=[NSString stringWithUTF8String:title];if(text) status.stringValue=[NSString stringWithUTF8String:text];updating=1;pageEntry.stringValue=[NSString stringWithFormat:@"%d",pages?page:0];pageTotal.stringValue=[NSString stringWithFormat:@"/ %d",pages];updating=0;
    pageEntry.hidden=pageTotal.hidden=previous.hidden=next.hidden=pages<=1;pageEntry.enabled=!running;previous.enabled=page>1 && !running;next.enabled=page<pages && !running;
    for(int i=1;i<32;i++) if(items[i]) items[i].enabled=!running;int ids[]={CMD_SAVE,CMD_SAVE_AS,CMD_EXPORT,CMD_CLOSE,CMD_CALIBRATE,CMD_MEASURE,CMD_FIT};for(size_t i=0;i<sizeof(ids)/sizeof(ids[0]);i++) items[ids[i]].enabled=app.document.bitmap && !running;items[CMD_RECORD].enabled=!recording && !running;items[CMD_STOP].enabled=recording && !running;items[CMD_RUN].enabled=!recording && !running;
}
void ui_message(const wchar_t *message) { if(!window) { char *s=utf8_from_wide(message);fprintf(stderr,"%s\n",s?s:"Native diagnostic failed.");free(s);return; }NSAlert *alert=[[[NSAlert alloc] init] autorelease];alert.messageText=@"lengto";alert.informativeText=nswide(message);[alert runModal]; }
int ui_dialog(const char *title,Field *fields,int count,const char *secondary) {
    NSAlert *alert=[[[NSAlert alloc] init] autorelease];alert.messageText=[NSString stringWithUTF8String:title];[alert addButtonWithTitle:@"Confirm"];if(secondary) [alert addButtonWithTitle:[NSString stringWithUTF8String:secondary]];[alert addButtonWithTitle:@"Cancel"];
    NSView *view=[[[NSView alloc] initWithFrame:NSMakeRect(0,0,400,count*60)] autorelease];NSMutableArray *controls=[NSMutableArray array];
    for(int i=0;i<count;i++) { CGFloat y=(count-i-1)*60;NSTextField *label=[NSTextField labelWithString:[NSString stringWithUTF8String:fields[i].label]];label.frame=NSMakeRect(0,y+32,400,20);[view addSubview:label];NSControl *control;
        if(fields[i].count) { NSPopUpButton *pop=[[[NSPopUpButton alloc] initWithFrame:NSMakeRect(0,y,400,28) pullsDown:NO] autorelease];for(int j=0;j<fields[i].count;j++) [pop addItemWithTitle:[NSString stringWithUTF8String:fields[i].options[j]]];[pop selectItemAtIndex:fields[i].index];control=pop; }
        else { NSTextField *entry=[[[NSTextField alloc] initWithFrame:NSMakeRect(0,y,400,26)] autorelease];entry.stringValue=[NSString stringWithUTF8String:fields[i].value];control=entry; }[view addSubview:control];[controls addObject:control];
    }if(count) alert.accessoryView=view;NSModalResponse result=[alert runModal];if(result==NSAlertFirstButtonReturn || (secondary && result==NSAlertSecondButtonReturn)) { [alert.window makeFirstResponder:nil];for(int i=0;i<count;i++) { if(fields[i].count) fields[i].index=(int)[controls[i] indexOfSelectedItem];else snprintf(fields[i].value,256,"%s",[[controls[i] stringValue] UTF8String]); }return result==NSAlertFirstButtonReturn?1:2; }return 0;
}
int ui_file(int save,const char *title,const char *extension,wchar_t *path) {
    NSSavePanel *panel=save?[NSSavePanel savePanel]:[NSOpenPanel openPanel];panel.title=[NSString stringWithUTF8String:title];panel.canCreateDirectories=YES;
    if(extension) panel.allowedFileTypes=@[[NSString stringWithUTF8String:extension]];else panel.allowedFileTypes=@[@"png",@"jpg",@"jpeg",@"tif",@"tiff",@"pdf"];
    if(save) panel.nameFieldStringValue=[NSString stringWithFormat:@"%s.%s",extension && !strcmp(extension,"py")?"macro":"drawing_measured",extension?extension:"png"];
    if([panel runModal]!=NSModalResponseOK) return 0;return wide_from_utf8(panel.URL.path.UTF8String,path,P2L_PATH);
}
int ui_paste(Document *out,wchar_t *error,size_t cap) {
    NSPasteboard *p=[NSPasteboard generalPasteboard];NSData *data=[p dataForType:NSPasteboardTypePNG];if(!data) data=[p dataForType:NSPasteboardTypeTIFF];if(data && document_from_memory(out,data.bytes,data.length,error,cap)) return 1;
    NSArray *urls=[p readObjectsForClasses:@[[NSURL class]] options:@{NSPasteboardURLReadingFileURLsOnlyKey:@YES}];wchar_t path[P2L_PATH];if(urls.count && wide_from_utf8([[[urls firstObject] path] UTF8String],path,P2L_PATH) && document_open(out,path,error,cap)) return 1;swprintf(error,cap,L"The clipboard does not contain a supported image or drawing file.");return 0;
}
void ui_url(const char *url) { [[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString:[NSString stringWithUTF8String:url]]]; }
void ui_text(const char *title,const wchar_t *text) { NSAlert *alert=[[[NSAlert alloc] init] autorelease];alert.messageText=[NSString stringWithUTF8String:title];[alert addButtonWithTitle:@"Close"];[alert addButtonWithTitle:@"GitHub"];NSScrollView *scroll=[[[NSScrollView alloc] initWithFrame:NSMakeRect(0,0,650,430)] autorelease];scroll.hasVerticalScroller=YES;NSTextView *view=[[[NSTextView alloc] initWithFrame:NSMakeRect(0,0,630,430)] autorelease];view.editable=NO;view.string=nswide(text);view.font=[NSFont systemFontOfSize:13];view.textContainer.widthTracksTextView=YES;scroll.documentView=view;alert.accessoryView=scroll;if([alert runModal]==NSAlertSecondButtonReturn) ui_url("https://github.com/IvanPanzera/lengto"); }
void ui_quit(void) { [NSApp stop:nil]; }
static NSMenu *menu(NSMenu *bar,NSString *title) { NSMenuItem *root=[[[NSMenuItem alloc] initWithTitle:title action:nil keyEquivalent:@""] autorelease];NSMenu *child=[[[NSMenu alloc] initWithTitle:title] autorelease];child.autoenablesItems=NO;root.submenu=child;[bar addItem:root];return child; }
static void item(NSMenu *menu,NSString *title,int command,NSString *key,NSEventModifierFlags flags) { NSMenuItem *i=[[[NSMenuItem alloc] initWithTitle:title action:@selector(command:) keyEquivalent:key] autorelease];i.target=delegate;i.tag=command;i.keyEquivalentModifierMask=flags;[menu addItem:i];items[command]=i; }
int ui_run(int argc,char **argv) { @autoreleasepool {
    [NSApplication sharedApplication];[NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];delegate=[[LengtoDelegate alloc] init];NSApp.delegate=delegate;
    NSMenu *bar=[[[NSMenu alloc] init] autorelease];bar.autoenablesItems=NO;NSApp.mainMenu=bar;NSMenu *application=menu(bar,@"lengto");NSMenuItem *quit=[[[NSMenuItem alloc] initWithTitle:@"Quit lengto" action:@selector(terminate:) keyEquivalent:@"q"] autorelease];[application addItem:quit];NSMenu *file=menu(bar,@"File"),*measure=menu(bar,@"Measurements"),*script=menu(bar,@"Script");
    item(file,@"Open…",CMD_OPEN,@"o",NSEventModifierFlagCommand);item(file,@"Paste",CMD_PASTE,@"v",NSEventModifierFlagCommand);item(file,@"Save",CMD_SAVE,@"s",NSEventModifierFlagCommand);item(file,@"Save as…",CMD_SAVE_AS,@"s",NSEventModifierFlagCommand|NSEventModifierFlagShift);item(file,@"Export…",CMD_EXPORT,@"",0);item(file,@"Run script…",CMD_RUN,@"",0);item(file,@"Close",CMD_CLOSE,@"w",NSEventModifierFlagCommand);
    item(measure,@"Calibrate",CMD_CALIBRATE,@"",0);item(measure,@"Measure",CMD_MEASURE,@"",0);item(measure,@"Settings…",CMD_SETTINGS,@"",0);item(script,@"Start recording…",CMD_RECORD,@"",0);item(script,@"Stop recording…",CMD_STOP,@"",0);item(bar,@"Fit",CMD_FIT,@"",0);NSMenu *help=menu(bar,@"?");item(help,@"Guide",CMD_GUIDE,@"",0);item(help,@"GitHub",CMD_GITHUB,@"",0);item(help,@"About",CMD_ABOUT,@"",0);
    window=[[NSWindow alloc] initWithContentRect:NSMakeRect(0,0,1100,760) styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable backing:NSBackingStoreBuffered defer:NO];window.title=@"lengto";window.delegate=delegate;window.acceptsMouseMovedEvents=YES;window.releasedWhenClosed=NO;NSView *root=window.contentView;
    canvas=[[LengtoView alloc] initWithFrame:NSMakeRect(0,30,1100,730)];canvas.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;[root addSubview:canvas];[canvas registerForDraggedTypes:@[NSPasteboardTypeFileURL]];
    status=[NSTextField labelWithString:@""];status.frame=NSMakeRect(8,5,820,20);status.autoresizingMask=NSViewWidthSizable;[root addSubview:status];previous=[NSButton buttonWithTitle:@"‹" target:delegate action:@selector(command:)];previous.tag=CMD_PREV;previous.frame=NSMakeRect(882,2,34,26);pageEntry=[[[NSTextField alloc] initWithFrame:NSMakeRect(920,4,52,24)] autorelease];pageEntry.target=delegate;pageEntry.action=@selector(page:);pageEntry.delegate=delegate;pageTotal=[NSTextField labelWithString:@""];pageTotal.frame=NSMakeRect(977,5,62,22);next=[NSButton buttonWithTitle:@"›" target:delegate action:@selector(command:)];next.tag=CMD_NEXT;next.frame=NSMakeRect(1050,2,34,26);for(NSView *v in @[previous,pageEntry,pageTotal,next]) { v.autoresizingMask=NSViewMinXMargin;[root addSubview:v]; }
    [window center];[window makeKeyAndOrderFront:nil];[window makeFirstResponder:canvas];[NSApp activateIgnoringOtherApps:YES];ui_title("lengto","",0,0,0,0);[NSTimer scheduledTimerWithTimeInterval:.02 target:delegate selector:@selector(tick:) userInfo:nil repeats:YES];
    if(argc==4 && !strcmp(argv[1],"--preview")) {
        wchar_t path[P2L_PATH];if(!wide_from_utf8(argv[2],path,P2L_PATH)) return 1;[window display];app_resize((int)canvas.bounds.size.width,(int)canvas.bounds.size.height);app_open(path);if(!app.document.bitmap) return 1;
        add_cal(&app.project,0,L"Calibration",(Point){100.5,130.5},(Point){600.5,130.5},5,UNIT_M);add_meas(&app.project,0,1,L"Width",(Point){100.5,420.5},(Point){600.5,420.5});
        if(app.document.pages>1) { [next performClick:nil];if(app.document.page!=1) return 1;pageEntry.stringValue=@"1";[delegate page:pageEntry];if(app.document.page!=0) return 1; }
        [window display];NSBitmapImageRep *rep=[root bitmapImageRepForCachingDisplayInRect:root.bounds];[root cacheDisplayInRect:root.bounds toBitmapImageRep:rep];NSData *data=[rep representationUsingType:NSBitmapImageFileTypePNG properties:@{}];return [data writeToFile:[NSString stringWithUTF8String:argv[3]] atomically:YES]?0:1;
    }
    if(argc>1 && strncmp(argv[1],"-psn",4)) { wchar_t path[P2L_PATH];if(wide_from_utf8(argv[1],path,P2L_PATH)) app_open(path); }[NSApp run];return 0;
} }
