#include "native.h"
#include "../portable.h"
#include <math.h>
#include <locale.h>
#include <signal.h>
App app;
static void update(void) {
    char title[1024]="lengto",status[256]="";Document *d=&app.document;
    if(*d->path) { char *p=utf8_from_wide(d->path);if(p) { const char *b=strrchr(p,'/');snprintf(title,sizeof(title),"%s%s — lengto",b?b+1:p,app.automation.dirty?" *":"");free(p); } }
    if(script_running()) strcpy(status,"Running script — Esc to stop");
    else if(app.mode) snprintf(status,sizeof(status),"%s: choose %s pixel — Esc to finish",app.mode==1?"Calibrate":app.mode==3?"Edit measure":"Measure",app.first?"the end":"the start");
    else if(app.recorder.active) strcpy(status,"Recording");
    else if(d->bitmap) { char *unit=utf8_from_wide(unit_name(app.project.display_unit));snprintf(status,sizeof(status),"%s � %s � step 10^%d m � %.0f%%%s",app.project.nc?"Calibration":"Not calibrated",unit?unit:"",app.project.precision_exp,app.view.sx*100,d->width+1<d->logical_width?" � reduced preview":"");free(unit); }
    ui_title(title,status,d->page+1,d->pages,app.recorder.active,script_running());ui_refresh();
}
static void fit(void) { Document *d=&app.document;View *v=&app.view;if(!d->bitmap) return;v->sx=v->sy=fmin(fmax(1,v->width-32)/d->logical_width,fmax(1,v->height-32)/d->logical_height);v->ox=(v->width-d->logical_width*v->sx)/2;v->oy=(v->height-d->logical_height*v->sy)/2; }
static int unsaved(void) {
    if(!app.automation.dirty) return 1;
    int answer=ui_dialog("Save changes before continuing?",NULL,0,"Discard");
    if(answer==2) return 1;if(answer==1) { app_command(CMD_SAVE);return !app.automation.dirty; }return 0;
}
void app_open(const wchar_t *path) {
    if(script_running() || !unsaved()) return;char *q=json_quote(path);Text command={0};if(!q) return;text_add(&command,"{\"op\":\"open\",\"path\":%s}",q);free(q);
    char *reply=automation_execute(&app.automation,command.data);text_free(&command);
    if(app.automation.changes&AUTO_OPEN) { app.mode=app.first=0;app.view.selected=-1;recorder_open(&app.recorder,&app.document);fit(); }
    else { Json j;wchar_t error[1024];if(reply && json_parse(&j,reply)) { if(json_wide(&j,"error",error,1024)) ui_message(error);json_free(&j); } }free(reply);update();
}
void app_page(int page) { wchar_t error[512];if(script_running() || page<1 || page>app.document.pages || page==app.document.page+1) return;if(document_page(&app.document,page-1,error,512)) { app.first=0;app.view.selected=-1;recorder_page(&app.recorder,page-1);fit(); }else ui_message(error);update(); }
static void unit_fields(Field *f,Unit selected,char labels[UNIT_COUNT][128],const char *items[UNIT_COUNT]) {
    *f=(Field){.label="Unit",.options=items,.count=UNIT_COUNT};
    for(int i=0;i<UNIT_COUNT;i++) { Unit u=unit_order(i);char *symbol=utf8_from_wide(unit_name(u)),*description=utf8_from_wide(unit_description(u));snprintf(labels[i],128,"%s — %s",symbol,description);free(symbol);free(description);items[i]=labels[i];if(u==selected) f->index=i; }
}
static int calibration(int existing) {
    Calibration *c=app.project.cal;char labels[UNIT_COUNT][128];const char *units[UNIT_COUNT];Field f[2]={{.label="Reference length"},{0}};double value;
    snprintf(f[0].value,256,"%.12g",existing?c->known:1);unit_fields(f+1,existing?c->unit:app.project.display_unit,labels,units);
    for(;;) { int answer=ui_dialog("Calibration",f,2,existing?"Change segment":NULL);if(!answer) return 0;wchar_t number[256];wide_from_utf8(f[0].value,number,256);
        if(!parse_positive(number,&value)) { ui_message(L"Enter a positive reference length.");continue; }
        app.pending_length=value;app.pending_unit=unit_order(f[1].index);
        if(answer==2 || !existing) { app.mode=1;app.first=0;return 1; }
        c->known=value;c->unit=app.pending_unit;app.automation.dirty=1;recorder_calibration(&app.recorder,&app.document,c);return 1;
    }
}
static void settings(void) {
    char labels[UNIT_COUNT][128],precision[27][32];const char *units[UNIT_COUNT],*steps[27];Field f[2];unit_fields(f,app.project.display_unit,labels,units);
    for(int i=0;i<27;i++) { snprintf(precision[i],32,"10^%d m",i-10);steps[i]=precision[i]; }
    f[1]=(Field){.label="Precision",.options=steps,.count=27,.index=app.project.precision_exp+10};
    if(ui_dialog("Settings",f,2,NULL)==1) { app.project.display_unit=unit_order(f[0].index);app.project.precision_exp=f[1].index-10;if(app.project.nm) app.automation.dirty=1;recorder_settings(&app.recorder,&app.project); }
}
static void save_file(int command) {
    static const char *formats[]={"TIFF (.tif)","JPEG (.jpg)","PNG (.png)","PDF (.pdf)"},*pages[]={"Current page","All pages"},*suffix[]={"tif","jpg","png","pdf"};
    wchar_t path[P2L_PATH]=L"",error[1024];ExportFormat format=app.automation.format;int all=app.automation.all_pages;
    if(command==CMD_SAVE && *app.automation.output) wcscpy(path,app.automation.output);
    else { Field f[2]={{.label="Format",.options=formats,.count=4,.index=format},{.label="Pages",.options=pages,.count=2,.index=all}};
        if(ui_dialog(command==CMD_EXPORT?"Export":"Save as",f,app.document.pages>1?2:1,NULL)!=1) return;format=(ExportFormat)f[0].index;all=app.document.pages>1?f[1].index:0;
        if(all && format!=EXPORT_TIFF && format!=EXPORT_PDF) { ui_message(L"Choose TIFF or PDF to save all pages.");return; }
        if(!ui_file(1,"Save drawing",suffix[format],path)) return;
    }
    if(!drawing_export(&app.document,&app.project,path,format,all,error,1024)) { ui_message(error);return; }
    wcscpy(app.automation.output,path);app.automation.format=format;app.automation.all_pages=all;app.automation.dirty=0;
    if(!all) { for(int i=0;i<app.project.nm;i++) if(app.project.meas[i].page!=app.document.page) app.automation.dirty=1;if(app.project.nc && app.project.cal[0].page!=app.document.page) app.automation.dirty=1; }
    recorder_export(&app.recorder,path,all);
}
void app_command(int command) {
    wchar_t path[P2L_PATH]=L"",error[1024];if(script_running()) return;
    switch(command) {
    case CMD_OPEN:if(ui_file(0,"Open drawing",NULL,path)) app_open(path);break;
    case CMD_PASTE: {
        if(!unsaved()) break;Document next={0};if(!ui_paste(&next,error,1024)) { document_close(&next);ui_message(error);break; }
        Unit u=app.project.display_unit;int precision=app.project.precision_exp;document_close(&app.document);app.document=next;project_init(&app.project,next.pages);app.project.display_unit=u;app.project.precision_exp=precision;app.automation.dirty=1;app.automation.output[0]=0;app.mode=app.first=0;app.view.selected=-1;recorder_open(&app.recorder,&app.document);fit();break;
    }
    case CMD_SAVE:case CMD_SAVE_AS:case CMD_EXPORT:if(app.document.bitmap) save_file(command);break;
    case CMD_CLOSE:if(unsaved()) { document_close(&app.document);Unit u=app.project.display_unit;int precision=app.project.precision_exp;project_init(&app.project,1);app.project.display_unit=u;app.project.precision_exp=precision;app.automation.dirty=0;app.automation.output[0]=0;app.mode=app.first=0;recorder_close(&app.recorder); }break;
    case CMD_CALIBRATE:if(app.document.bitmap) { app.mode=app.first=0;calibration(app.project.nc!=0); }break;
    case CMD_MEASURE:if(app.document.bitmap) { if(!app.project.nc) calibration(0);else { app.mode=2;app.first=0; } }break;
    case CMD_SETTINGS:settings();break;
    case CMD_FIT:fit();break;
    case CMD_PREV:app_page(app.document.page);break;
    case CMD_NEXT:app_page(app.document.page+2);break;
    case CMD_RECORD:if(!app.recorder.active) { const char *options[]={"Relative (fractions)","Absolute (pixels)"};Field f={.label="Coordinates",.options=options,.count=2};if(ui_dialog("Start recording",&f,1,NULL)==1 && !recorder_start(&app.recorder,&app.document,&app.project,f.index==0)) ui_message(app.recorder.error); }break;
    case CMD_STOP:if(app.recorder.active && ui_file(1,"Save Python macro","py",path) && !recorder_save(&app.recorder,path)) ui_message(*app.recorder.error?app.recorder.error:L"Cannot save the macro. Recording is still available.");break;
    case CMD_RUN:if(app.recorder.active) ui_message(L"Finish recording before running a script.");else if(ui_file(0,"Run Python script","py",path) && !script_start(path,app.executable,error,1024)) ui_message(error);break;
    case CMD_GUIDE:case CMD_ABOUT: {
        wchar_t *text=portable_text(command==CMD_GUIDE?RESOURCE_GUIDE:RESOURCE_LICENSES);if(text) { ui_text(command==CMD_GUIDE?"lengto — Guide":"lengto — About and licenses",text);free(text); }break;
    }
    case CMD_GITHUB:ui_url("https://github.com/IvanPanzera/lengto");break;
    }update();
}
void app_resize(int w,int h) { int first=!app.view.width;app.view.width=w;app.view.height=h;if(first) fit(); }
void app_draw(void *context) {
    paint_rect(context,0,0,app.view.width,app.view.height,RGB(235,236,237));
    if(app.document.bitmap) { render_drawing(context,&app.document,&app.project,&app.view);if(app.mode && app.first) { wchar_t label[180];Calibration *c=app.project.cal;if(app.mode!=1 && app.project.nc) format_length(point_distance(app.anchor,app.cursor)*c->known*unit_metres(c->unit)/point_distance(c->a,c->b),app.project.display_unit,app.project.precision_exp,label,180);else swprintf(label,180,L"%.2f px",point_distance(app.anchor,app.cursor));render_segment(context,&app.view,app.anchor,app.cursor,RGB(52,60,65),1,1,label); } }
    else { const wchar_t *text=L"open, drop or paste";paint_text(context,(app.view.width-text_width(text,17))/2,(app.view.height-17)/2,text,17,RGB(100,104,108)); }
}
static int snap(double x,double y,Point *out) { View *v=&app.view;double xx=(x-v->ox)/v->sx,yy=(y-v->oy)/v->sy;if(xx<0 || yy<0 || xx>=app.document.logical_width || yy>=app.document.logical_height) return 0;*out=(Point){floor(xx)+.5,floor(yy)+.5};return 1; }
void app_mouse(int action,double x,double y) {
    if(!app.document.bitmap || script_running()) return;
    if(action==3 && !app.mode) {
        int index=hit_measurement(&app.project,app.document.page,&app.view,(int)x,(int)y);if(index<0) return;app.view.selected=index;Measurement *m=app.project.meas+index;
        Field f={.label="Name"};char *name=utf8_from_wide(m->name);if(name) snprintf(f.value,256,"%s",name);free(name);
        int answer=ui_dialog("Edit measurement",&f,1,"Change segment");if(answer) {
            wchar_t value[P2L_NAME];int valid=wide_from_utf8(f.value,value,P2L_NAME) && *value;for(size_t i=0;valid && value[i];i++) if(value[i]<32) valid=0;
            if(!valid) ui_message(L"Enter a name with 1 to 79 characters.");
            else { wcscpy(m->name,value);app.automation.dirty=1;recorder_measurement(&app.recorder,&app.document,m,1);if(answer==2) { app.replace_measure=index;app.mode=3;app.first=0; } }
        }update();return;
    }
    if(action==0) { app.down=1;app.dragging=0;app.start_x=x;app.start_y=y;app.origin_x=app.view.ox;app.origin_y=app.view.oy; }
    if(action==1) { if(app.down && (app.dragging || hypot(x-app.start_x,y-app.start_y)>3)) { app.dragging=1;app.view.ox=app.origin_x+x-app.start_x;app.view.oy=app.origin_y+y-app.start_y; }if(snap(x,y,&app.cursor) && app.first && app.shift) { if(fabs(app.cursor.x-app.anchor.x)>fabs(app.cursor.y-app.anchor.y)) app.cursor.y=app.anchor.y;else app.cursor.x=app.anchor.x; }ui_refresh(); }
    if(action==2 && app.down) { app.down=0;if(app.dragging) return;
        if(!app.mode) app.view.selected=hit_measurement(&app.project,app.document.page,&app.view,(int)x,(int)y);
        else { Point p;if(!snap(x,y,&p)) return;if(!app.first) { app.anchor=app.cursor=p;app.first=1; }
            else {
                if(app.shift) { if(fabs(p.x-app.anchor.x)>fabs(p.y-app.anchor.y)) p.y=app.anchor.y;else p.x=app.anchor.x; }
                if(point_distance(app.anchor,p)<1) return;
                if(app.mode==1) {
                    if(app.project.nc) { Calibration *c=app.project.cal;c->a=app.anchor;c->b=p;c->page=app.document.page;c->known=app.pending_length;c->unit=app.pending_unit; }
                    else add_cal(&app.project,app.document.page,L"Calibration",app.anchor,p,app.pending_length,app.pending_unit);
                    recorder_calibration(&app.recorder,&app.document,app.project.cal);app.automation.dirty=1;app.mode=0;
                }else if(app.mode==3) { Measurement *m=app.project.meas+app.replace_measure;m->a=app.anchor;m->b=p;recorder_measurement(&app.recorder,&app.document,m,1);app.automation.dirty=1;app.mode=0; }
                else { wchar_t name[P2L_NAME];swprintf(name,P2L_NAME,L"Measure %d",app.project.next_meas);int id=add_meas(&app.project,app.document.page,app.project.cal[0].id,name,app.anchor,p);if(id) { app.view.selected=app.project.nm-1;app.automation.dirty=1;recorder_measurement(&app.recorder,&app.document,app.project.meas+app.view.selected,0); }else ui_message(L"The limit of 4096 measurements has been reached."); }app.first=0;
            }
        }update();
    }
}
void app_zoom(double steps,double x,double y) {
    if(!app.document.bitmap || script_running()) return;View *v=&app.view;double sx=v->sx,scale=fmax(1e-8,fmin(fmax(v->width,v->height),sx*pow(1.2,steps)));v->ox=x-(x-v->ox)*scale/sx;v->oy=y-(y-v->oy)*scale/sx;v->sx=v->sy=scale;update();
}
void app_key(int key) {
    if(key==27) { if(script_running()) script_cancel();app.mode=app.first=app.down=0; }
    if(key==127 && !script_running() && app.view.selected>=0 && app.view.selected<app.project.nm) { recorder_delete(&app.recorder,app.project.meas[app.view.selected].id);remove_meas(&app.project,app.view.selected);app.view.selected=-1;app.automation.dirty=1; }update();
}
int app_quit(void) {
    if(script_running()) { script_cancel();ui_message(L"Stopping the script. Close lengto again when it has finished.");return 0; }
    if(!unsaved()) return 0;if(app.recorder.active) { int a=ui_dialog("Save the recorded macro before closing?",NULL,0,"Discard");if(!a) return 0;if(a==1) { app_command(CMD_STOP);if(app.recorder.active) return 0; } }return 1;
}
void app_tick(void) { int was=script_running();script_poll();if(was || script_running()) { if(app.automation.changes&AUTO_OPEN) { fit();app.view.selected=-1;app.mode=app.first=0; }else if(app.automation.changes&AUTO_VIEW) fit();app.automation.changes=0;update(); } }
int main(int argc,char **argv) {
    setlocale(LC_ALL,"");setlocale(LC_NUMERIC,"C");signal(SIGPIPE,SIG_IGN);if(!imaging_init()) return 1;
    if(argc>1 && !strcmp(argv[1],"--automation")) { int code=automation_stdio();imaging_shutdown();return code; }
    project_init(&app.project,1);app.automation.document=&app.document;app.automation.project=&app.project;app.automation.format=EXPORT_PNG;app.view.selected=-1;app.view.sx=app.view.sy=1;
    char *exe=realpath(argv[0],NULL);snprintf(app.executable,sizeof(app.executable),"%s",exe?exe:argv[0]);free(exe);
    if(argc==5 && !strcmp(argv[1],"--script-test")) { int code=app_diagnostics(argv[2],argv[3],argv[4]);recorder_reset(&app.recorder);document_close(&app.document);imaging_shutdown();return code; }
    int code=ui_run(argc,argv);recorder_reset(&app.recorder);document_close(&app.document);imaging_shutdown();return code;
}
