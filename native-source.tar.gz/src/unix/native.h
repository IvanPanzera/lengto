#ifndef LENGTO_NATIVE_H
#define LENGTO_NATIVE_H
#include "../recorder.h"
/* Native backends use an opaque BGRA raster with a top-left origin. */
HBITMAP raster_new(int width,int height);
void *source_open(const char *path,int *pages,int *pdf);
void source_close(void *source);
HBITMAP source_page(void *source,int page);
HBITMAP source_memory(const void *data,size_t size);
unsigned char *raster_png(HBITMAP raster,size_t *size);
void *writer_open(const char *path,ExportFormat format);
int writer_page(void *writer,HBITMAP raster,double width,double height);
int writer_close(void *writer);
void *paint_begin(HBITMAP raster);
void paint_end(void *context);
void paint_rect(void *context,double x,double y,double w,double h,COLORREF color);
void paint_image(void *context,HBITMAP raster,double x,double y,double w,double h,int nearest);
void paint_line(void *context,double x,double y,double xx,double yy,COLORREF color,double width,int dashed);
void paint_text(void *context,double x,double y,const wchar_t *text,double size,COLORREF color);
double text_width(const wchar_t *text,double size);

enum { CMD_OPEN=1,CMD_PASTE,CMD_SAVE,CMD_SAVE_AS,CMD_EXPORT,CMD_RUN,CMD_CLOSE,
       CMD_CALIBRATE,CMD_MEASURE,CMD_SETTINGS,CMD_RECORD,CMD_STOP,CMD_FIT,CMD_GUIDE,CMD_GITHUB,CMD_ABOUT,CMD_PREV,CMD_NEXT };
typedef struct { const char *label;char value[256];const char **options;int count,index; } Field;
int ui_run(int argc,char **argv);
void ui_refresh(void);
void ui_message(const wchar_t *message);
/* Returns 1 for Confirm, 2 for the optional secondary action, 0 on dismissal. */
int ui_dialog(const char *title,Field *fields,int count,const char *secondary);
int ui_file(int save,const char *title,const char *extension,wchar_t *path);
int ui_paste(Document *out,wchar_t *error,size_t cap);
void ui_text(const char *title,const wchar_t *text);
void ui_url(const char *url);
void ui_title(const char *title,const char *status,int page,int pages,int recording,int running);
void ui_quit(void);

typedef struct {
    Document document;Project project;Automation automation;Recorder recorder;View view;
    int mode,first,down,dragging,shift,replace_measure;double mouse_x,mouse_y,start_x,start_y,origin_x,origin_y;
    double pending_length;Unit pending_unit;
    Point anchor,cursor;char executable[4096];
} App;
extern App app;
void app_command(int command);
void app_open(const wchar_t *path);
void app_page(int page);
void app_resize(int width,int height);
void app_draw(void *context);
void app_mouse(int action,double x,double y); /* 0 down, 1 move, 2 up, 3 context edit */
void app_zoom(double steps,double x,double y);
void app_key(int key); /* 27 Escape, 127 Delete */
int app_quit(void);
void app_tick(void);
int script_start(const wchar_t *path,const char *executable,wchar_t *error,size_t cap);
int script_running(void);
void script_cancel(void);
void script_poll(void);
int app_diagnostics(const char *source,const char *recorded,const char *python);
#endif
