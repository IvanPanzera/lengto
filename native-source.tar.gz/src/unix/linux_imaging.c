#include "native.h"
#include <png.h>
#include <jpeglib.h>
#include <tiffio.h>
#include <cairo.h>
#include <cairo-pdf.h>
#include <fpdfview.h>
#include <setjmp.h>
#include <math.h>

typedef struct { char *path;int kind;TIFF *tiff;FPDF_DOCUMENT pdf; } Source;
int imaging_init(void) { FPDF_InitLibrary();return 1; }
void imaging_shutdown(void) { FPDF_DestroyLibrary(); }
static void opaque(HBITMAP r,int premultiplied) {
    for(size_t i=0;i<(size_t)r->width*r->height;i++) { unsigned char *p=r->pixels+i*4;unsigned a=p[3];for(int j=0;j<3;j++) p[j]=(unsigned char)(premultiplied ? min(255,p[j]+255-a) : (p[j]*a+255*(255-a)+127)/255);p[3]=255; }
}
static HBITMAP read_png(const void *data,size_t size,const char *path) {
    png_image im={0};HBITMAP r=NULL;im.version=PNG_IMAGE_VERSION;
    if(!(path?png_image_begin_read_from_file(&im,path):png_image_begin_read_from_memory(&im,data,size))) return NULL;
    r=raster_new((int)im.width,(int)im.height);im.format=PNG_FORMAT_BGRA;
    if(r && !png_image_finish_read(&im,NULL,r->pixels,0,NULL)) { bitmap_free(r);r=NULL; }png_image_free(&im);if(r) opaque(r,0);return r;
}
typedef struct { struct jpeg_error_mgr error;jmp_buf jump; } JpegError;
static void jpeg_fail(j_common_ptr c) { longjmp(((JpegError *)c->err)->jump,1); }
static HBITMAP read_jpeg(const char *path) {
    FILE *f=fopen(path,"rb");struct jpeg_decompress_struct c={0};JpegError err;HBITMAP volatile r=NULL;unsigned char *volatile row=NULL;if(!f) return NULL;
    c.err=jpeg_std_error(&err.error);err.error.error_exit=jpeg_fail;
    if(setjmp(err.jump)) { bitmap_free(r);r=NULL;goto done; }
    jpeg_create_decompress(&c);jpeg_stdio_src(&c,f);jpeg_read_header(&c,TRUE);c.out_color_space=JCS_RGB;jpeg_start_decompress(&c);r=raster_new((int)c.output_width,(int)c.output_height);if(!r) goto done;row=malloc((size_t)c.output_width*3);if(!row) { bitmap_free(r);r=NULL;goto done; }
    while(c.output_scanline<c.output_height) { unsigned y=c.output_scanline;JSAMPROW rows[1]={row};jpeg_read_scanlines(&c,rows,1);for(unsigned x=0;x<c.output_width;x++) { unsigned char *p=r->pixels+((size_t)y*r->width+x)*4;p[0]=row[x*3+2];p[1]=row[x*3+1];p[2]=row[x*3];p[3]=255; } }jpeg_finish_decompress(&c);
done:free(row);jpeg_destroy_decompress(&c);fclose(f);return r;
}
void *source_open(const char *path,int *pages,int *pdf) {
    unsigned char signature[5]={0};FILE *f=fopen(path,"rb");Source *s;if(!f) return NULL;size_t n=fread(signature,1,5,f);fclose(f);if(n<4) return NULL;
    s=calloc(1,sizeof(*s));if(!s) return NULL;s->path=strdup(path);*pdf=0;*pages=1;
    if(!memcmp(signature,"%PDF",4)) { s->kind=3;s->pdf=FPDF_LoadDocument(path,NULL);if(!s->pdf) goto fail;*pages=FPDF_GetPageCount(s->pdf);*pdf=1; }
    else if(!memcmp(signature,"II",2) || !memcmp(signature,"MM",2)) { s->kind=2;s->tiff=TIFFOpen(path,"r");if(!s->tiff) goto fail;*pages=TIFFNumberOfDirectories(s->tiff); }
    else if(signature[0]==137 && !memcmp(signature+1,"PNG",3)) s->kind=0;
    else if(signature[0]==255 && signature[1]==216) s->kind=1;else goto fail;
    if(*pages<1) goto fail;return s;
fail:source_close(s);return NULL;
}
void source_close(void *source) { Source *s=source;if(!s) return;if(s->pdf) FPDF_CloseDocument(s->pdf);if(s->tiff) TIFFClose(s->tiff);free(s->path);free(s); }
HBITMAP source_page(void *source,int page) {
    Source *s=source;HBITMAP r=NULL;if(s->kind==0) return read_png(NULL,0,s->path);if(s->kind==1) return read_jpeg(s->path);
    if(s->kind==2) {
        uint32_t w,h;if(!TIFFSetDirectory(s->tiff,(tdir_t)page) || !TIFFGetField(s->tiff,TIFFTAG_IMAGEWIDTH,&w) || !TIFFGetField(s->tiff,TIFFTAG_IMAGELENGTH,&h)) return NULL;
        r=raster_new((int)w,(int)h);if(!r) return NULL;if(!TIFFReadRGBAImageOriented(s->tiff,w,h,(uint32_t *)r->pixels,ORIENTATION_TOPLEFT,0)) { bitmap_free(r);return NULL; }
        for(size_t i=0;i<(size_t)w*h;i++) { unsigned char *p=r->pixels+i*4;unsigned char t=p[0];p[0]=p[2];p[2]=t; }opaque(r,1);return r;
    }
    FPDF_PAGE p=FPDF_LoadPage(s->pdf,page);if(!p) return NULL;double w=ceil(FPDF_GetPageWidth(p)*2),h=ceil(FPDF_GetPageHeight(p)*2);
    if(w>0 && h>0 && w<=100000000 && h<=100000000) r=raster_new((int)w,(int)h);
    if(r) { FPDF_BITMAP b=FPDFBitmap_CreateEx(r->width,r->height,FPDFBitmap_BGRA,r->pixels,r->width*4);if(!b) { bitmap_free(r);r=NULL; }else { FPDFBitmap_FillRect(b,0,0,r->width,r->height,0xffffffff);FPDF_RenderPageBitmap(b,p,0,0,r->width,r->height,0,FPDF_ANNOT);FPDFBitmap_Destroy(b); } }FPDF_ClosePage(p);return r;
}
HBITMAP source_memory(const void *data,size_t size) { return read_png(data,size,NULL); }
unsigned char *raster_png(HBITMAP r,size_t *size) {
    png_image im={0};png_alloc_size_t n=0;unsigned char *data;im.version=PNG_IMAGE_VERSION;im.width=r->width;im.height=r->height;im.format=PNG_FORMAT_BGRA;
    if(!png_image_write_to_memory(&im,NULL,&n,0,r->pixels,0,NULL)) return NULL;data=malloc(n);if(!data) return NULL;
    if(!png_image_write_to_memory(&im,data,&n,0,r->pixels,0,NULL)) { free(data);return NULL; }*size=n;return data;
}
typedef struct { ExportFormat format;char *path;FILE *file;TIFF *tiff;cairo_surface_t *pdf;int pages,failed; } Writer;
void *writer_open(const char *path,ExportFormat format) {
    Writer *w=calloc(1,sizeof(*w));if(!w) return NULL;w->path=strdup(path);w->format=format;
    if(format==EXPORT_TIFF) w->tiff=TIFFOpen(path,"w");else if(format==EXPORT_PDF) w->pdf=cairo_pdf_surface_create(path,1,1);else w->file=fopen(path,"wb");
    if(!(w->tiff || w->pdf || w->file)) { writer_close(w);return NULL; }return w;
}
static int jpeg_write(FILE *f,HBITMAP r) {
    struct jpeg_compress_struct c={0};JpegError err;unsigned char *volatile row=NULL;volatile int ok=0;c.err=jpeg_std_error(&err.error);err.error.error_exit=jpeg_fail;
    if(setjmp(err.jump)) goto done;jpeg_create_compress(&c);jpeg_stdio_dest(&c,f);c.image_width=r->width;c.image_height=r->height;c.input_components=3;c.in_color_space=JCS_RGB;jpeg_set_defaults(&c);jpeg_set_quality(&c,95,TRUE);jpeg_start_compress(&c,TRUE);row=malloc((size_t)r->width*3);if(!row) goto done;
    while(c.next_scanline<c.image_height) { const unsigned char *p=r->pixels+(size_t)c.next_scanline*r->width*4;for(int x=0;x<r->width;x++) { row[x*3]=p[x*4+2];row[x*3+1]=p[x*4+1];row[x*3+2]=p[x*4]; }JSAMPROW rows[1]={row};jpeg_write_scanlines(&c,rows,1); }jpeg_finish_compress(&c);ok=1;
done:free(row);jpeg_destroy_compress(&c);return ok;
}
int writer_page(void *writer,HBITMAP r,double width,double height) {
    Writer *w=writer;int ok=0;if(w->failed || (w->pages && (w->format==EXPORT_PNG || w->format==EXPORT_JPEG))) return 0;
    if(w->format==EXPORT_PNG) { size_t n;unsigned char *data=raster_png(r,&n);ok=data && fwrite(data,1,n,w->file)==n;free(data); }
    else if(w->format==EXPORT_JPEG) ok=jpeg_write(w->file,r);
    else if(w->format==EXPORT_PDF) { cairo_pdf_surface_set_size(w->pdf,width,height);cairo_t *cr=cairo_create(w->pdf);paint_image(cr,r,0,0,width,height,1);cairo_show_page(cr);ok=cairo_status(cr)==CAIRO_STATUS_SUCCESS;cairo_destroy(cr); }
    else {
        TIFF *t=w->tiff;TIFFSetField(t,TIFFTAG_IMAGEWIDTH,r->width);TIFFSetField(t,TIFFTAG_IMAGELENGTH,r->height);TIFFSetField(t,TIFFTAG_SAMPLESPERPIXEL,3);TIFFSetField(t,TIFFTAG_BITSPERSAMPLE,8);TIFFSetField(t,TIFFTAG_ORIENTATION,ORIENTATION_TOPLEFT);TIFFSetField(t,TIFFTAG_PLANARCONFIG,PLANARCONFIG_CONTIG);TIFFSetField(t,TIFFTAG_PHOTOMETRIC,PHOTOMETRIC_RGB);TIFFSetField(t,TIFFTAG_COMPRESSION,COMPRESSION_ADOBE_DEFLATE);TIFFSetField(t,TIFFTAG_ROWSPERSTRIP,TIFFDefaultStripSize(t,0));TIFFSetField(t,TIFFTAG_XRESOLUTION,144.0);TIFFSetField(t,TIFFTAG_YRESOLUTION,144.0);TIFFSetField(t,TIFFTAG_RESOLUTIONUNIT,RESUNIT_INCH);
        unsigned char *row=malloc((size_t)r->width*3);ok=row!=NULL;for(int y=0;y<r->height && ok;y++) { const unsigned char *p=r->pixels+(size_t)y*r->width*4;for(int x=0;x<r->width;x++) { row[x*3]=p[x*4+2];row[x*3+1]=p[x*4+1];row[x*3+2]=p[x*4]; }ok=TIFFWriteScanline(t,row,y,0)>=0; }free(row);if(ok) ok=TIFFWriteDirectory(t);
    }w->pages++;w->failed=!ok;return ok;
}
int writer_close(void *writer) {
    Writer *w=writer;if(!w) return 0;int ok=!w->failed && w->pages>0;
    if(w->tiff) TIFFClose(w->tiff);if(w->pdf) { cairo_surface_finish(w->pdf);if(cairo_surface_status(w->pdf)) ok=0;cairo_surface_destroy(w->pdf); }if(w->file && fclose(w->file)) ok=0;free(w->path);free(w);return ok;
}
