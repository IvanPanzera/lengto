#include "native.h"
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
static struct { pid_t pid;int input,output,errors,cancelled,failed;char pending[1024*1024],diagnostic[8193];size_t used,diagnostic_size;Text outgoing;size_t sent;time_t stopped; } runner;
int script_running(void) { return runner.pid>0; }
int script_start(const wchar_t *path,const char *executable,wchar_t *error,size_t cap) {
    int in[2]={-1,-1},out[2]={-1,-1},err[2]={-1,-1};char *file=utf8_from_wide(path);if(!file) return 0;
    if(pipe(in) || pipe(out) || pipe(err)) goto fail;pid_t pid=fork();if(pid<0) goto fail;
    if(!pid) {
        setpgid(0,0);dup2(in[0],STDIN_FILENO);dup2(out[1],STDOUT_FILENO);dup2(err[1],STDERR_FILENO);
        for(int i=0;i<2;i++) { close(in[i]);close(out[i]);close(err[i]); }
        setenv("LENGTO_HOSTED","1",1);setenv("LENGTO_EXE",executable,1);setenv("PYTHONIOENCODING","utf-8",1);setenv("PYTHONUNBUFFERED","1",1);
        /* Do not inject the portable app's libraries into the user's Python. */
        const char *original=getenv("LENGTO_ORIGINAL_LD_LIBRARY_PATH");if(original) { if(*original) setenv("LD_LIBRARY_PATH",original,1);else unsetenv("LD_LIBRARY_PATH"); }
        unsetenv("GDK_PIXBUF_MODULEDIR");unsetenv("GDK_PIXBUF_MODULE_FILE");
        const char *python=getenv("LENGTO_PYTHON");if(python && *python) execlp(python,python,file,(char *)NULL);else execlp("python3","python3",file,(char *)NULL);
        fputs("Cannot start Python 3. Install Python 3.8+ or set LENGTO_PYTHON to its executable.\n",stderr);_exit(127);
    }
    close(in[0]);close(out[1]);close(err[1]);memset(&runner,0,sizeof(runner));runner.pid=pid;setpgid(pid,pid);runner.input=in[1];runner.output=out[0];runner.errors=err[0];fcntl(in[1],F_SETFL,O_NONBLOCK);fcntl(out[0],F_SETFL,O_NONBLOCK);fcntl(err[0],F_SETFL,O_NONBLOCK);free(file);return 1;
fail:for(int i=0;i<2;i++) { if(in[i]>=0) close(in[i]);if(out[i]>=0) close(out[i]);if(err[i]>=0) close(err[i]); }free(file);swprintf(error,cap,L"Cannot start the script process.");return 0;
}
void script_cancel(void) { if(runner.pid && !runner.cancelled) { runner.cancelled=1;runner.stopped=time(NULL);kill(-runner.pid,SIGTERM); } }
static void flush_reply(void) {
    while(runner.sent<runner.outgoing.len) { ssize_t n=write(runner.input,runner.outgoing.data+runner.sent,runner.outgoing.len-runner.sent);if(n<0 && errno==EINTR) continue;if(n<0 && (errno==EAGAIN || errno==EWOULDBLOCK)) return;if(n<=0) { runner.failed=1;script_cancel();return; }runner.sent+=(size_t)n; }
    text_free(&runner.outgoing);runner.sent=0;
}
void script_poll(void) {
    if(!runner.pid) return;char errors[2048];ssize_t n;
    while((n=read(runner.errors,errors,sizeof(errors)))>0) { size_t keep=min((size_t)n,8192-runner.diagnostic_size);memcpy(runner.diagnostic+runner.diagnostic_size,errors,keep);runner.diagnostic_size+=keep;runner.diagnostic[runner.diagnostic_size]=0; }
    if(runner.cancelled && time(NULL)-runner.stopped>=2) kill(-runner.pid,SIGKILL);
    flush_reply();
    /* Bound work per tick so long macros leave drawing and cancellation responsive. */
    for(int commands=0;commands<16 && !runner.cancelled && !runner.outgoing.len;commands++) {
        char *line=memchr(runner.pending,'\n',runner.used);
        if(!line) { if(runner.used>=sizeof(runner.pending)-1) { runner.failed=1;script_cancel();break; }n=read(runner.output,runner.pending+runner.used,sizeof(runner.pending)-runner.used-1);if(n<=0) break;runner.used+=(size_t)n;runner.pending[runner.used]=0;line=memchr(runner.pending,'\n',runner.used);if(!line) { if(runner.used>=sizeof(runner.pending)-1) { runner.failed=1;script_cancel(); }break; } }
        *line=0;unsigned changes=app.automation.changes;char *reply=automation_execute(&app.automation,runner.pending);app.automation.changes|=changes;
        if(!reply) { runner.failed=1;script_cancel();break; }text_add(&runner.outgoing,"%s\n",reply);free(reply);size_t consumed=(size_t)(line-runner.pending)+1;memmove(runner.pending,runner.pending+consumed,runner.used-consumed);runner.used-=consumed;flush_reply();
    }
    int status;if(waitpid(runner.pid,&status,WNOHANG)==runner.pid) {
        /* A child can leave descendants holding pipes; terminate its process group. */
        kill(-runner.pid,SIGTERM);close(runner.input);close(runner.output);close(runner.errors);runner.pid=0;text_free(&runner.outgoing);
        if(runner.failed || (!runner.cancelled && (!WIFEXITED(status) || WEXITSTATUS(status)))) { wchar_t error[9000];if(!*runner.diagnostic || !wide_from_utf8(runner.diagnostic,error,9000)) wcscpy(error,L"The script failed. Check its Python code and interpreter.");ui_message(error); }
    }
}
