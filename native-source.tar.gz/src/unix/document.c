#include "native.h"
#include <math.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>

static wchar_t last_error[512];
HBITMAP raster_new(int w,int h) {
    HBITMAP r;if(w<=0 || h<=0 || w>100000000 || (double)w*h>268435456) return NULL;
    r=calloc(1,sizeof(*r));if(!r) return NULL;r->width=w;r->height=h;r->pixels=malloc((size_t)w*h*4);
    if(!r->pixels) { free(r);return NULL; }memset(r->pixels,255,(size_t)w*h*4);return r;
}
void bitmap_free(HBITMAP r) { if(r) { free(r->pixels);free(r); } }
static int use_page(Document *d,HBITMAP original) {
    if(!original) return 0;
    double scale=fmin(1,fmin(32767.0/fmax(original->width,original->height),sqrt(24.0*1024*1024/((double)original->width*original->height))));
    int w=max(1,(int)floor(original->width*scale)),h=max(1,(int)floor(original->height*scale));HBITMAP preview=scale==1?original:raster_new(w,h);
    if(!preview) { bitmap_free(original);return 0; }
    if(preview!=original) for(int y=0;y<h;y++) for(int x=0;x<w;x++) memcpy(preview->pixels+((size_t)y*w+x)*4,original->pixels+((size_t)((int)((double)y*original->height/h))*original->width+(int)((double)x*original->width/w))*4,4);
    if(d->bitmap!=d->original) bitmap_free(d->bitmap);bitmap_free(d->original);d->original=original;d->bitmap=preview;d->width=w;d->height=h;d->pixels=preview->pixels;d->logical_width=original->width;d->logical_height=original->height;return 1;
}
int document_page(Document *d,int page,wchar_t *error,size_t cap) {
    if(page<0 || page>=d->pages) goto fail;if(page==d->page && d->bitmap) return 1;
    if(!d->backend || !use_page(d,source_page(d->backend,page))) goto fail;d->page=page;return 1;
fail:swprintf(error,cap,L"Cannot decode this page, or the image exceeds the available memory (maximum 268 million pixels).");return 0;
}
int document_open(Document *d,const wchar_t *path,wchar_t *error,size_t cap) {
    char *utf=utf8_from_wide(path);if(!utf) return 0;d->backend=source_open(utf,&d->pages,&d->pdf);free(utf);d->page=-1;
    if(d->backend && document_page(d,0,error,cap)) { wcsncpy(d->path,path,P2L_PATH-1);return 1; }
    swprintf(error,cap,L"Cannot open this drawing. Choose a supported TIFF, PNG, JPEG or PDF file.");document_close(d);return 0;
}
int document_from_memory(Document *d,const void *data,size_t size,wchar_t *error,size_t cap) {
    HBITMAP r=source_memory(data,size);if(!r || !use_page(d,r)) { swprintf(error,cap,L"Cannot decode the clipboard image.");return 0; }d->pages=1;d->page=0;d->clipboard=1;return 1;
}
int document_open_image(Document *d,const wchar_t *path,wchar_t *error,size_t cap) {
    if(!document_open(d,path,error,cap)) return 0;
    /* Detach from temporary files created by Python open_image(). */
    source_close(d->backend);d->backend=NULL;d->pages=1;d->page=0;d->pdf=0;d->clipboard=1;d->path[0]=0;return 1;
}
void document_close(Document *d) { source_close(d->backend);if(d->bitmap!=d->original) bitmap_free(d->bitmap);bitmap_free(d->original);memset(d,0,sizeof(*d)); }
int document_rgb(Document *d,int x,int y,int w,int h,unsigned char *rgb) {
    HBITMAP r=d->original;if(!r || x<0 || y<0 || w<=0 || h<=0 || w>r->width-x || h>r->height-y || (double)w*h>65536) return 0;
    for(int yy=0;yy<h;yy++) for(int xx=0;xx<w;xx++) { unsigned char *p=r->pixels+((size_t)(y+yy)*r->width+x+xx)*4;*rgb++=p[2];*rgb++=p[1];*rgb++=p[0]; }return 1;
}
unsigned char *document_png(Document *d,size_t *size) { return d->original ? raster_png(d->original,size) : NULL; }
int bitmap_save_png(HBITMAP r,const wchar_t *path) { size_t n;unsigned char *data=raster_png(r,&n);int ok=data && atomic_write(path,data,n);free(data);return ok; }
struct ExportJob { char *path,*temp;void *writer;int failed; };
const wchar_t *export_error(void) { return *last_error ? last_error : L"Cannot create the output file."; }
ExportJob *export_begin(const wchar_t *path,ExportFormat format) {
    ExportJob *job=calloc(1,sizeof(*job));int fd;wcscpy(last_error,L"Cannot create the output file. Check its folder and available disk space.");if(!job) return NULL;
    job->path=utf8_from_wide(path);if(!job->path) goto fail;job->temp=malloc(strlen(job->path)+16);if(!job->temp) goto fail;sprintf(job->temp,"%s.XXXXXX",job->path);
    fd=mkstemp(job->temp);if(fd<0) goto fail;close(fd);job->writer=writer_open(job->temp,format);if(!job->writer) goto fail;return job;
fail:export_abort(job);return NULL;
}
int export_append(ExportJob *job,HBITMAP r,double w,double h) { if(!job || job->failed) return 0;job->failed=!writer_page(job->writer,r,w,h);return !job->failed; }
int export_finish(ExportJob *job) {
    int ok=!job->failed;if(!writer_close(job->writer)) ok=0;job->writer=NULL;
    if(ok) { int fd=open(job->temp,O_RDONLY);if(fd<0 || fsync(fd)) ok=0;if(fd>=0) close(fd); }
    if(ok) ok=!rename(job->temp,job->path);if(!ok) unlink(job->temp);free(job->temp);free(job->path);free(job);return ok;
}
void export_abort(ExportJob *job) { if(!job) return;if(job->writer) writer_close(job->writer);if(job->temp) unlink(job->temp);free(job->temp);free(job->path);free(job); }
