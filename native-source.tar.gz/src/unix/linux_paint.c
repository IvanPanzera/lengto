#include "native.h"
#include <cairo.h>
static void color(cairo_t *cr,COLORREF c) { cairo_set_source_rgb(cr,(c&255)/255.,((c>>8)&255)/255.,((c>>16)&255)/255.); }
void *paint_begin(HBITMAP r) { cairo_surface_t *s=cairo_image_surface_create_for_data(r->pixels,CAIRO_FORMAT_ARGB32,r->width,r->height,r->width*4);cairo_t *cr=cairo_create(s);cairo_surface_destroy(s);return cr; }
void paint_end(void *dc) { cairo_surface_flush(cairo_get_target(dc));cairo_destroy(dc); }
void paint_rect(void *dc,double x,double y,double w,double h,COLORREF c) { cairo_t *cr=dc;cairo_save(cr);color(cr,c);cairo_rectangle(cr,x,y,w,h);cairo_fill(cr);cairo_restore(cr); }
void paint_image(void *dc,HBITMAP r,double x,double y,double w,double h,int nearest) {
    cairo_t *cr=dc;cairo_surface_t *s=cairo_image_surface_create_for_data(r->pixels,CAIRO_FORMAT_ARGB32,r->width,r->height,r->width*4);
    cairo_save(cr);cairo_translate(cr,x,y);cairo_scale(cr,w/r->width,h/r->height);cairo_set_source_surface(cr,s,0,0);cairo_pattern_set_filter(cairo_get_source(cr),nearest?CAIRO_FILTER_NEAREST:CAIRO_FILTER_BILINEAR);cairo_rectangle(cr,0,0,r->width,r->height);cairo_fill(cr);cairo_restore(cr);cairo_surface_destroy(s);
}
void paint_line(void *dc,double x,double y,double xx,double yy,COLORREF c,double width,int dashed) {
    cairo_t *cr=dc;double dash[]={5,4};cairo_save(cr);color(cr,c);cairo_set_line_width(cr,width);if(dashed) cairo_set_dash(cr,dash,2,0);cairo_move_to(cr,x,y);cairo_line_to(cr,xx,yy);cairo_stroke(cr);cairo_restore(cr);
}
void paint_text(void *dc,double x,double y,const wchar_t *text,double size,COLORREF c) { cairo_t *cr=dc;char *s=utf8_from_wide(text);if(!s) return;cairo_save(cr);color(cr,c);cairo_select_font_face(cr,"sans-serif",CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_NORMAL);cairo_set_font_size(cr,size);cairo_move_to(cr,x,y+size);cairo_show_text(cr,s);cairo_restore(cr);free(s); }
double text_width(const wchar_t *text,double size) { char *s=utf8_from_wide(text);cairo_surface_t *surface=cairo_image_surface_create(CAIRO_FORMAT_A8,1,1);cairo_t *cr=cairo_create(surface);cairo_text_extents_t e={0};cairo_set_font_size(cr,size);if(s) cairo_text_extents(cr,s,&e);free(s);cairo_destroy(cr);cairo_surface_destroy(surface);return e.x_advance; }
