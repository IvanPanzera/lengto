/* Explicit command-line diagnostics; never run during normal application use. */
#include "native.h"
#include <math.h>
#include <time.h>
#define CHECK(x) do { if(!(x)) { fprintf(stderr,"Check failed at %s:%d: %s\n",__FILE__,__LINE__,#x);return 1; } } while(0)
static int wait_script(int seconds) { time_t end=time(NULL)+seconds;while(script_running() && time(NULL)<end) { script_poll();usleep(10000); }return !script_running(); }
int app_diagnostics(const char *source,const char *recorded,const char *python) {
    Document *d=&app.document;Project *p=&app.project;Recorder *r=&app.recorder;wchar_t input[P2L_PATH],output[P2L_PATH],macro[P2L_PATH],error[1024];
    CHECK(wide_from_utf8(source,input,P2L_PATH));CHECK(wide_from_utf8(recorded,macro,P2L_PATH));setenv("LENGTO_PYTHON",python,1);
    CHECK(recorder_start(r,d,p,1));CHECK(document_open(d,input,error,1024));project_init(p,d->pages);recorder_open(r,d);
    CHECK(add_cal(p,0,L"Calibration",(Point){100.5,130.5},(Point){600.5,130.5},5,UNIT_M));recorder_calibration(r,d,p->cal);
    CHECK(add_meas(p,0,1,L"Deleted",(Point){100.5,200.5},(Point){300.5,200.5}));recorder_measurement(r,d,p->meas,0);recorder_delete(r,1);remove_meas(p,0);
    CHECK(add_meas(p,0,1,L"Edited",(Point){100.5,300.5},(Point){300.5,300.5}));recorder_measurement(r,d,p->meas,0);p->meas[0].b.x=400.5;recorder_measurement(r,d,p->meas,1);
    CHECK(document_page(d,1,error,1024));recorder_page(r,1);CHECK(add_meas(p,1,1,L"Page two",(Point){10.5,10.5},(Point){110.5,10.5}));recorder_measurement(r,d,p->meas+1,0);
    swprintf(output,P2L_PATH,L"%ls.pdf",macro);CHECK(drawing_export(d,p,output,EXPORT_PDF,1,error,1024));recorder_export(r,output,1);CHECK(recorder_save(r,macro));
    CHECK(recorder_start(r,d,p,0));swprintf(output,P2L_PATH,L"%ls.snapshot.py",macro);CHECK(recorder_save(r,output));
    CHECK(script_start(macro,app.executable,error,1024));CHECK(wait_script(20));CHECK(p->nm==2 && d->page==1);
    CHECK(document_page(d,0,error,1024));size_t size;unsigned char *png=document_png(d,&size);CHECK(png);document_close(d);CHECK(document_from_memory(d,png,size,error,1024));free(png);project_init(p,1);CHECK(add_cal(p,0,L"Calibration",(Point){100.5,130.5},(Point){600.5,130.5},5,UNIT_M));CHECK(add_meas(p,0,1,L"Clipboard",(Point){100.5,300.5},(Point){300.5,300.5}));CHECK(recorder_start(r,d,p,1));swprintf(output,P2L_PATH,L"%ls.clipboard.pdf",macro);recorder_export(r,output,0);swprintf(output,P2L_PATH,L"%ls.clipboard.py",macro);CHECK(recorder_save(r,output));
    /* Exercise the same controller used by both native interfaces. */
    app_resize(800,600);app_command(CMD_FIT);app_command(CMD_MEASURE);View *v=&app.view;
    for(int i=0;i<2;i++) { app_mouse(0,v->ox+200.2*v->sx,v->oy+400.8*v->sy);app_mouse(2,v->ox+200.2*v->sx,v->oy+400.8*v->sy);app_mouse(0,v->ox+300.8*v->sx,v->oy+400.2*v->sy);app_mouse(2,v->ox+300.8*v->sx,v->oy+400.2*v->sy); }CHECK(p->nm==3 && app.mode==2);CHECK(p->meas[1].a.x==200.5 && p->meas[1].b.x==300.5);app_key(27);CHECK(!app.mode);
    app_mouse(0,20,20);app_mouse(1,70,60);app_mouse(2,70,60);double old=v->ox;app_zoom(100,400,300);CHECK(v->sx>=v->width && isfinite(v->ox) && v->ox!=old);
    HBITMAP image=raster_new(800,600);CHECK(image);void *cr=paint_begin(image);CHECK(cr);app_draw(cr);paint_end(cr);CHECK(image->pixels[400*4+300*800*4+3]==255);bitmap_free(image);
    swprintf(output,P2L_PATH,L"%ls.cancel.py",macro);const char *sleep="import time\ntime.sleep(30)\n";CHECK(atomic_write(output,sleep,strlen(sleep)));CHECK(script_start(output,app.executable,error,1024));script_cancel();CHECK(wait_script(5));
    return 0;
}
