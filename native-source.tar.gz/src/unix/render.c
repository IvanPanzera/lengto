#include "native.h"
#include <math.h>
static COLORREF teal=RGB(0,119,126);
POINT view_point(const View *v,Point p) { POINT s={(int)lround(fmax(-1e8,fmin(1e8,p.x*v->sx+v->ox))),(int)lround(fmax(-1e8,fmin(1e8,p.y*v->sy+v->oy)))};return s; }
static void label_box(const View *v,POINT a,POINT b,const wchar_t *label,double *x,double *y,double *w,double *h) {
    double size=v->font ? (double)(uintptr_t)v->font : 14;*w=text_width(label,size)+8;*h=size+6;*x=fmax(4,fmin(v->width-*w-4,(a.x+b.x-*w)/2));*y=fmax(4,fmin(v->height-*h-4,(a.y+b.y)/2-*h-6));
}
void render_segment(HDC dc,const View *v,Point a,Point b,COLORREF color,int reference,int selected,const wchar_t *label) {
    POINT s=view_point(v,a),t=view_point(v,b);double x,y,w,h,size=v->font ? (double)(uintptr_t)v->font : 14;
    if(max(s.x,t.x)<-10 || min(s.x,t.x)>v->width+10 || max(s.y,t.y)<-10 || min(s.y,t.y)>v->height+10) return;
    paint_line(dc,s.x,s.y,t.x,t.y,color,reference?1:selected?3:2,reference);
    paint_line(dc,s.x-3,s.y-3,s.x+3,s.y+3,color,2,0);paint_line(dc,t.x-3,t.y-3,t.x+3,t.y+3,color,2,0);
    if(selected) { paint_rect(dc,s.x-3,s.y-3,6,6,color);paint_rect(dc,t.x-3,t.y-3,6,6,color); }
    if(label && *label) { label_box(v,s,t,label,&x,&y,&w,&h);paint_rect(dc,x,y,w,h,RGB(255,255,255));paint_text(dc,x+4,y+2,label,size,color); }
}
void render_drawing(HDC dc,const Document *d,const Project *p,const View *v) {
    if(!d->bitmap) return;
    double px=v->sx*d->logical_width/d->width,py=v->sy*d->logical_height/d->height;
    if(px>=16 || py>=16) {
        int x0=(int)fmax(0,fmin(d->width,floor(-v->ox/px))),x1=(int)fmax(0,fmin(d->width,ceil((v->width-v->ox)/px)));
        int y0=(int)fmax(0,fmin(d->height,floor(-v->oy/py))),y1=(int)fmax(0,fmin(d->height,ceil((v->height-v->oy)/py)));
        for(int y=y0;y<y1;y++) for(int x=x0;x<x1;x++) { const unsigned char *c=d->pixels+((size_t)y*d->width+x)*4;double l=fmax(0,v->ox+x*px),t=fmax(0,v->oy+y*py),r=fmin(v->width,v->ox+(x+1)*px),b=fmin(v->height,v->oy+(y+1)*py);paint_rect(dc,l,t,r-l,b-t,RGB(c[2],c[1],c[0])); }
    }else paint_image(dc,d->bitmap,v->ox,v->oy,d->logical_width*v->sx,d->logical_height*v->sy,px>=1 && py>=1);
    wchar_t label[256];
    if(p->nc && p->cal[0].page==d->page) { const Calibration *c=p->cal;swprintf(label,256,L"Calibration · %.10g %ls",c->known,unit_name(c->unit));render_segment(dc,v,c->a,c->b,teal,1,0,label); }
    for(int i=0;i<p->nm;i++) { const Measurement *m=p->meas+i;if(m->page!=d->page) continue;format_length(measured_metres(p,m),p->display_unit,p->precision_exp,label,256);render_segment(dc,v,m->a,m->b,teal,0,i==v->selected,label); }
}
int hit_measurement(const Project *p,int page,const View *v,int x,int y) {
    double nearest=8;int best=-1;
    for(int i=p->nm-1;i>=0;i--) { const Measurement *m=p->meas+i;if(m->page!=page) continue;POINT a=view_point(v,m->a),b=view_point(v,m->b);double dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy,t=l?fmax(0,fmin(1,((x-a.x)*dx+(y-a.y)*dy)/l)):0,dist=hypot(x-a.x-t*dx,y-a.y-t*dy),xx,yy,w,h;wchar_t label[256];format_length(measured_metres(p,m),p->display_unit,p->precision_exp,label,256);label_box(v,a,b,label,&xx,&yy,&w,&h);if(x>=xx && x<=xx+w && y>=yy && y<=yy+h) return i;if(dist<nearest) { best=i;nearest=dist; } }return best;
}
HBITMAP render_export(const Document *d,const Project *p) {
    HBITMAP r=raster_new(d->width,d->height);if(!r) return NULL;void *dc=paint_begin(r);if(!dc) { bitmap_free(r);return NULL; }
    View v={.sx=d->width/d->logical_width,.sy=d->height/d->logical_height,.width=d->width,.height=d->height,.selected=-1,.font=(HFONT)(uintptr_t)max(14,min(48,d->width/100))};render_drawing(dc,d,p,&v);paint_end(dc);return r;
}
