#ifndef LENGTO_PORTABLE_H
#define LENGTO_PORTABLE_H
#include "platform.h"
#define RESOURCE_PDFIUM 101
#define RESOURCE_LICENSES 102
#define RESOURCE_GUIDE 103
#define RESOURCE_PYTHON 104
#ifdef _WIN32
HMODULE portable_load_pdfium(void);
void portable_pdfium_cleanup(void);
#endif
/* Caller frees the returned wide text. */
wchar_t *portable_text(int id);
#endif
