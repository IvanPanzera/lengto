#ifndef LENGTO_PLATFORM_H
#define LENGTO_PLATFORM_H
#include <stddef.h>
#include <wchar.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#ifdef _WIN32
#include <windows.h>
#else
#include <stdint.h>
#include <unistd.h>
#include <strings.h>
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
#define _strdup strdup
#define _wcsicmp wcscasecmp
typedef struct Raster { int width,height; unsigned char *pixels; } *HBITMAP;
typedef void *HDC;
typedef void *HFONT;
typedef void *HWND;
typedef struct { int x,y; } POINT;
typedef unsigned COLORREF;
#define RGB(r,g,b) ((unsigned)(r)|((unsigned)(g)<<8)|((unsigned)(b)<<16))
void bitmap_free(HBITMAP bitmap);
#define DeleteObject bitmap_free
#endif
/* Strict UTF-8 conversion, independent of the user's process locale. */
char *utf8_from_wide(const wchar_t *text);
int wide_from_utf8(const char *text,wchar_t *out,size_t capacity);
int full_path(const wchar_t *path,wchar_t *out,size_t capacity);
int atomic_write(const wchar_t *path,const void *data,size_t size);
#endif
