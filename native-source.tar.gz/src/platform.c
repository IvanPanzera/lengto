#define _CRT_SECURE_NO_WARNINGS
#include "platform.h"
#include <limits.h>
#include <errno.h>
#ifdef _WIN32
#include <io.h>
#else
#include <fcntl.h>
#include <sys/stat.h>
#endif
char *utf8_from_wide(const wchar_t *s) {
    size_t len=wcslen(s),n=0;char *out=malloc(len*4+1);if(!out) return NULL;
    for(size_t i=0;i<len;i++) {
        unsigned c=(unsigned)s[i];
        if(sizeof(wchar_t)==2 && c>=0xd800 && c<=0xdbff) {
            unsigned lo=(unsigned)s[++i];if(lo<0xdc00 || lo>0xdfff) goto fail;
            c=0x10000+((c-0xd800)<<10)+(lo-0xdc00);
        }
        if(c>0x10ffff || (c>=0xd800 && c<=0xdfff)) goto fail;
        if(c<128) out[n++]=(char)c;
        else if(c<2048) { out[n++]=(char)(0xc0|(c>>6));out[n++]=(char)(0x80|(c&63)); }
        else if(c<65536) { out[n++]=(char)(0xe0|(c>>12));out[n++]=(char)(0x80|((c>>6)&63));out[n++]=(char)(0x80|(c&63)); }
        else { out[n++]=(char)(0xf0|(c>>18));out[n++]=(char)(0x80|((c>>12)&63));out[n++]=(char)(0x80|((c>>6)&63));out[n++]=(char)(0x80|(c&63)); }
    }out[n]=0;return out;
fail:free(out);return NULL;
}
int wide_from_utf8(const char *s,wchar_t *out,size_t cap) {
    size_t n=0;const unsigned char *p=(const unsigned char *)s;
    while(*p) {
        unsigned c=*p++,minimum=0;int extra=0;
        if(c>=0xc2 && c<=0xdf) { c&=31;extra=1;minimum=128; }
        else if(c>=0xe0 && c<=0xef) { c&=15;extra=2;minimum=2048; }
        else if(c>=0xf0 && c<=0xf4) { c&=7;extra=3;minimum=65536; }
        else if(c>=128) return 0;
        while(extra--) { if((*p&0xc0)!=0x80) return 0;c=(c<<6)|(*p++&63); }
        if(c<minimum || c>0x10ffff || (c>=0xd800 && c<=0xdfff)) return 0;
        if(sizeof(wchar_t)==2 && c>=65536) { if(n+2>=cap) return 0;c-=65536;if(out) out[n]=(wchar_t)(0xd800+(c>>10));n++;c=0xdc00+(c&1023); }
        if(n+1>=cap) return 0;if(out) out[n]=(wchar_t)c;n++;
    }if(!cap) return 0;if(out) out[n]=0;return 1;
}
int full_path(const wchar_t *path,wchar_t *out,size_t cap) {
#ifdef _WIN32
    DWORD n=GetFullPathNameW(path,(DWORD)cap,out,NULL);return n>0 && n<cap;
#else
    char *s=utf8_from_wide(path),*resolved=NULL;int ok=0;if(!s) return 0;
    resolved=realpath(s,NULL);
    if(!resolved) { /* Export destinations need not exist yet. Resolve their parent. */
        char *slash=strrchr(s,'/'),*parent,*base;
        if(slash) { *slash=0;base=slash+1;parent=realpath(*s?s:"/",NULL); }
        else { base=s;parent=realpath(".",NULL); }
        if(parent && *base && strcmp(base,".") && strcmp(base,"..")) { resolved=malloc(strlen(parent)+strlen(base)+2);if(resolved) sprintf(resolved,"%s/%s",parent,base); }free(parent);
    }
    if(resolved) ok=wide_from_utf8(resolved,out,cap);free(resolved);free(s);return ok;
#endif
}
int atomic_write(const wchar_t *path,const void *data,size_t size) {
#ifdef _WIN32
    wchar_t *temp=malloc((wcslen(path)+48)*sizeof(wchar_t));FILE *f;int ok=0;if(!temp) return 0;
    swprintf(temp,wcslen(path)+48,L"%ls.%lu.tmp",path,GetCurrentProcessId());f=_wfopen(temp,L"wb");
    if(f) { ok=fwrite(data,1,size,f)==size && !fflush(f);if(ok) ok=FlushFileBuffers((HANDLE)_get_osfhandle(_fileno(f)));if(fclose(f)) ok=0;if(ok) ok=MoveFileExW(temp,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0; }
    if(!ok) DeleteFileW(temp);free(temp);return ok;
#else
    char *dest=utf8_from_wide(path),*temp;int fd,ok=0;size_t at=0;if(!dest) return 0;
    temp=malloc(strlen(dest)+16);if(!temp) { free(dest);return 0; }sprintf(temp,"%s.XXXXXX",dest);fd=mkstemp(temp);
    if(fd>=0) { while(at<size) { ssize_t n=write(fd,(const char *)data+at,size-at);if(n<0 && errno==EINTR) continue;if(n<=0) break;at+=(size_t)n; }ok=at==size && !fsync(fd);if(close(fd)) ok=0;if(ok) ok=!rename(temp,dest); }
    if(!ok) unlink(temp);free(temp);free(dest);return ok;
#endif
}
